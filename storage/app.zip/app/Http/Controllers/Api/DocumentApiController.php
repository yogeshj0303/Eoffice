<?php

namespace App\Http\Controllers\Api;
use App\Models\Document;
use App\Models\Newchecklist;
use App\Models\User;
use App\Models\Salary;
use App\Models\Checklist;
use App\Models\Receipt;
use App\Models\ChecklistMaster;
use App\Models\UserDocument;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DocumentApiController extends Controller
{ 
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */
public function documentList(Request $request)
{
    // Fetch all documents
    $documents = Document::all();

    // Check if any documents exist
    if ($documents->isEmpty()) {
        // Return a response indicating no documents were found
        return response()->json([
            'success' => false,
            'message' => 'No documents found.'
        ], 404); // 404 Not Found status code
    }

    // Return a successful response with the documents data
    return response()->json([
        'success' => true,
        'data' => $documents
    ], 200); // 200 OK status code
}

public function documentStore(Request $request)
{
 

    // Check if the user exists (this is redundant if you use the validation above)
    $userExists = User::where('id', $request->user_id)->exists();

    if (!$userExists) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404); // 404 status code indicates that the resource was not found
    }

    $savedDocuments = [];

    // Loop through each document and store it
    foreach ($request->documents as $doc) {
        // Ensure that document_pdf is a valid file
        if (isset($doc['document_pdf']) && $doc['document_pdf']->isValid()) {
            // Handle the file upload
            $file = $doc['document_pdf'];
            $ext = $file->getClientOriginalExtension();
            $filename = date('Y-m-d') . '-' . rand() . '.' . $ext;
            $file->move(public_path('uploads/document/'), $filename);

            // Create a new UserDocument instance
            $document = new UserDocument();
            $document->user_id = $request->user_id;
            $document->document_name = $doc['document_name'];
            $document->document_pdf =$filename;
            $document->state = $request->state;
            $document->district = $request->district;
            $document->taluka = $request->taluka;
            // Save the document
            $document->save();

            // Add the saved document to the response array
            $savedDocuments[] = $document;
        }
    }

    // Return a JSON response with the created documents and a success message
    return response()->json([
        'success' => true,
        'message' => 'Documents added successfully.',
        'data' => $savedDocuments
    ], 201); // 201 status code indicates that a resource has been successfully created
}


public function getCheckList(Request $request)
{
    // Fetch all documents
    $checklist = Checklist::select('name')->get();

    // Check if any documents exist
    if ($checklist->isEmpty()) {
        // Return a response indicating no documents were found
        return response()->json([
            'success' => false,
            'message' => 'No Checklist found.'
        ], 404); // 404 Not Found status code
    }

    // Return a successful response with the documents data
    return response()->json([
        'success' => true,
        'data' => $checklist
    ], 200); // 200 OK status code
}

public function getBookCheckList(Request $request)
{
    // Fetch all documents
    $checklist = ChecklistMaster::select('checklist_name')->get();

    // Check if any documents exist
    if ($checklist->isEmpty()) {
        // Return a response indicating no documents were found
        return response()->json([
            'success' => false,
            'message' => 'No Checklist found.'
        ], 404); // 404 Not Found status code
    }

    // Return a successful response with the documents data
    return response()->json([
        'success' => true,
        'data' => $checklist
    ], 200); // 200 OK status code
}



// receipt sectiopn 
public function receiptStore(Request $request)
{
 

    // Check if the user exists (this is redundant if you use the validation above)
    $userExists = User::where('id', $request->user_id)->exists();

    if (!$userExists) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404); // 404 status code indicates that the resource was not found
    }


       // Handle the file upload
    $filename = null; // Initialize filename
    if ($request->hasFile('receipt_pdf') && $request->file('receipt_pdf')->isValid()) {
        // Get file extension
        $ext = $request->file('receipt_pdf')->getClientOriginalExtension();
        // Generate unique file name
        $filename = date('Y-m-d') . '-' . rand() . '.' . $ext;
        // Move file to the desired location
        $request->file('receipt_pdf')->move(public_path('uploads/document/'), $filename);
    }
    
 
    // Generate a new receipt number
    $lastReceipt = Receipt::orderBy('id', 'desc')->first(); // Get the last receipt
    $newReceiptNo = 'R-' . date('Ymd') . '-' . str_pad(($lastReceipt ? $lastReceipt->id + 1 : 1), 4, '0', STR_PAD_LEFT);


    // Create a new Receipt instance
    $document = new Receipt();
    $document->user_id = $request->user_id;
    $document->receipt_checklist_id = $request->category;
    $document->subject = $request->subject;
    $document->description = $request->description;
    $document->receipt_pdf = $filename;
     $document->receipt_no = $newReceiptNo; 

    // Save the document
    $document->save();

    // Return a JSON response with the created document and success message
    return response()->json([
        'success' => true,
        'message' => 'Receipt added successfully.',
        'data' => $document
    ], 201); // 201 status code indicates resource creation
}

public function receiptGet(Request $request)
{
 

    // Check if the user exists (this is redundant if you use the validation above)
    $userExists = User::where('id', $request->user_id)->exists();

    if (!$userExists) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404); // 404 status code indicates that the resource was not found
    }
    
     // Fetch all documents
    $getReceipt = Receipt::where('user_id',$request->user_id)->get();
 $getpendingReceipt = Receipt::where('user_id',$request->user_id)->where('receipt_status','pending')->count();
 
  $getApprovedReceipt = Receipt::where('user_id',$request->user_id)->where('receipt_status','approved')->count();
  
   $getRejectedReceipt = Receipt::where('user_id',$request->user_id)->where('receipt_status','rejected')->count();
   
   
    // Check if any documents exist
    if ($getReceipt->isEmpty()) {
        // Return a response indicating no documents were found
        return response()->json([
            'success' => false,
            'message' => 'No Receipt found.'
        ], 404); // 404 Not Found status code
    }

    // Return a successful response with the documents data
    return response()->json([
        'success' => true,
        'data' => $getReceipt,
        'Pending_receipts' => $getpendingReceipt,
        'Approved_receipts' => $getApprovedReceipt,
        'Rejected_receipts' => $getRejectedReceipt
    ], 200); // 200 OK status code

}


// checklist api
public function storeChecklist(Request $request)
{

   $user = User::where('id', $request->user_id)->first();

    if (!$user) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404); // 404 status code indicates that the resource was not found
    }

    // Fetch user-related data (assuming relationships exist in the User model)
    $data['state'] = $user->state; 
    
    $data['district'] = $user->district;
    
    $data['org_id'] = $user->org_id; // Assuming 'organization' relationship
    $data['depart_id'] = $user->depart_id;
    $data['taluka'] = $user->taluka; 
    
    $data['design_id'] = $user->design_id;
    
    // Collect other data directly from the request
    $data['checklist_name'] = $request->input('checklist_name');
    $data['process_status'] = $request->input('process_status');
    $data['page_no'] = $request->input('page_no');
    $data['Status'] = $request->input('Status');
    $data['receipt_status'] = null;
    $data['receipt_no'] = $request->input('receipt_no');
$data['user_id'] = $request->input('user_id');
    // Handle file upload if the page_file is present
    if ($request->hasFile('page_file')) {
        $file = $request->file('page_file');
        $destinationPath = public_path('/images');
        $fileName = time() . '-' . $file->getClientOriginalName();
        $file->move($destinationPath, $fileName);

        $data['page_file'] = $fileName;
    }

    // Create a new checklist record in the database
    $newChecklist = Newchecklist::create($data);

    // Return a JSON response
    return response()->json([
        'status' => 'success',
        'message' => 'Checklist created successfully!',
        'data' => $newChecklist,
    ], 201); // 201 Created status code
}


public function checklistStatusGet(Request $request)
{
 

    // Check if the user exists (this is redundant if you use the validation above)
    $userExists = User::where('id', $request->user_id)->exists();

    if (!$userExists) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404); // 404 status code indicates that the resource was not found
    }
    
     // Fetch all documents
    $getReceipt = Newchecklist::where('user_id',$request->user_id)->get();
 $getpendingReceipt = Newchecklist::where('user_id',$request->user_id)->where('Status','pending')->count();
 
  $getApprovedReceipt = Newchecklist::where('user_id',$request->user_id)->where('Status','complete')->count();
  
   $getRejectedReceipt = Newchecklist::where('user_id',$request->user_id)->where('Status','rejected')->count();
   
   
    // Check if any documents exist
    if ($getReceipt->isEmpty()) {
        // Return a response indicating no documents were found
        return response()->json([
            'success' => false,
            'message' => 'No Checklist found.'
        ], 404); // 404 Not Found status code
    }

    // Return a successful response with the documents data
    return response()->json([
        'success' => true,
        'data' => $getReceipt,
        'Pending_checklist' => $getpendingReceipt,
        'Approved_checklist' => $getApprovedReceipt,
        'Rejected_checklist' => $getRejectedReceipt
    ], 200); // 200 OK status code

}


public function storePromotion(Request $request)
{
    // Fetch the user based on the user_id
    $user = User::where('id', $request->user_id)->first();

    // Check if the user exists
    if (!$user) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404); // 404 status code indicates that the resource was not found
    }

    // Collect data directly from the user model for state, district, etc.
    $data = $request->all();
    $data['state'] = $user->state;
    $data['district'] = $user->district;
    $data['org_id'] = $user->org_id;
    $data['depart_id'] = $user->depart_id;
    $data['design_id'] = $user->design_id;
    $data['taluka'] = $user->taluka;
    // Calculate end year salary based on user ID (`user_id`)
    $endYearSalary = $this->calculateEndYearSalary($request->user_id);
    $salaryToStore = $request->salary < $endYearSalary ? $endYearSalary : $request->salary;

    // Check if a salary record already exists for the user
    $salary = Salary::where('user_id', $request->user_id)->first();

    // Handle file uploads (user_dig_sig and additional_document)
    $filePaths = [];
    $files = [
        'user_dig_sig' => $request->file('user_dig_sig'),
        'additional_document' => $request->file('additional_document'),
    ];

    foreach ($files as $key => $file) {
        if ($file) {
            $filePath = $file->move(public_path('images'), $file->getClientOriginalName());
            $filePaths[$key] = 'images/' . $file->getClientOriginalName();
        }
    }

    // Update the salary record if it exists
    if ($salary) {
        // Check if the existing record's status is 'complete'
        if ($salary->status === 'complete') {
            return response()->json([
                'success' => false,
                'message' => 'This user record is already complete.',
            ], 400); // 400 Bad Request
        }

        // Update the existing salary record with the new data
        $salary->update(array_merge($filePaths, $data));

        // Check if all files are present, then update the status
        if ($salary->user_dig_sig) {
            $salary->status = 'complete';
            $salary->save();
        }

        return response()->json([
            'success' => true,
            'message' => 'Salary record updated successfully.',
            'data' => $salary
        ], 200); // 200 OK
    } else {
        // Create a new salary record if it doesn't exist
        $status = 'pending';
        if ($request->hasFile('user_dig_sig')) {
            $status = 'complete';
        }

        $newSalary = Salary::create(array_merge(
            $data,
            ['user_id' => $request->input('user_id')],
            ['promotion_salary' => $salaryToStore],
            ['status' => $status],
            $filePaths
        ));

        return response()->json([
            'success' => true,
            'message' => 'Salary record created successfully.',
            'data' => $newSalary
        ], 201); // 201 Created
    }
}


private function calculateEndYearSalary($userId)
{
    $user = User::find($userId);
    $currentSalary = $user->joining_start_salary;
    $joiningYear = date('Y', strtotime($user->joining_date));
    $promotionYears = ($user->salary_type == 'education') ? 10 : 12;

    // Apply salary increment for each year starting from the joining year
    for ($year = 1; $year <= $promotionYears; $year++) {
        $currentSalary += $currentSalary * 0.03;
    }

    return $currentSalary;
}

}