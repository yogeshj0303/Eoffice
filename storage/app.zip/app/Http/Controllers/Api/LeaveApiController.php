<?php

namespace App\Http\Controllers\Api;
use App\Models\Leave;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LeaveApiController extends Controller
{ 
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */
public function leaveStore(Request $request)
{
    
        // Check if the user exists
    $userExists = User::where('id', $request->user_id)->exists();

    if (!$userExists) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404); // 404 status code indicates that the resource was not found
    }

    // Create a new Leave instance
    $leave = new Leave();

    // Assign request data to the Leave model properties
    $leave->user_id = $request->user_id;
    $leave->state = $request->state;
    $leave->district = $request->district;
    $leave->taluka = $request->taluka;
    $leave->subject = $request->subject;
    $leave->description = $request->description;
    $leave->start_date = $request->start_date;
    $leave->end_date = $request->end_date;
    $leave->apply_start_date = $request->apply_start_date;
    $leave->apply_end_date = $request->apply_end_date;
    $leave->status = "pending";
    // Save the Leave record to the database
    $leave->save();

    // Return a JSON response with the created leave record and a success message
    return response()->json([
        'success' => true,
        'message' => 'Leave added successfully.',
        'data' => $leave
    ], 201); // 201 status code indicates that a resource has been successfully created
}

public function getLeaveAccordingStatus(Request $request)
{
    // Get the leave count grouped by month and status
    $leaveStats = Leave::selectRaw('
            YEAR(created_at) as year, 
            MONTH(created_at) as month, 
            status, 
            COUNT(*) as total
        ')
        ->where('user_id', $request->user_id)
        ->groupBy('year', 'month', 'status')
        ->get();

    // Organize the data by month and status
    $monthlyLeaveStatus = [];

    foreach ($leaveStats as $leave) {
        $month = $leave->month . '-' . $leave->year; // Format: Month-Year
        
        // Initialize the array for each month if not exists
        if (!isset($monthlyLeaveStatus[$month])) {
            $monthlyLeaveStatus[$month] = [
                'Approved' => 0,
                'Pending' => 0,
                'Rejected' => 0
            ];
        }
        
        // Assign leave counts based on status
        switch ($leave->status) {
            case 'approved':
                $monthlyLeaveStatus[$month]['Approved'] = $leave->total;
                break;
            case 'pending':
                $monthlyLeaveStatus[$month]['Pending'] = $leave->total;
                break;
            case 'rejected':
                $monthlyLeaveStatus[$month]['Rejected'] = $leave->total;
                break;
        }
    }

    return response()->json([
        'success' => true,
        'data' => $monthlyLeaveStatus
    ], 201);
}


}
