<?php

namespace App\Http\Controllers\Api;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoginApiController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */
public function loginViaOtp(Request $request)
    {
        // Validate the request

        $mobile = $request->input('mobile');

        // Find user by mobile number
        $user = User::where('number', $mobile)->where('is_admin','employee')->first();

        if (!$user) {
            return response()->json(['error' => 'User not found.'], 404);
        }

      
        return response()->json(['msg' => "Login Successfully" , 'data' => $user]);
    }
    
public function testVerifyDigitalSignature()
{
    // Path to test data, signature, and public key files
    $dataPath = public_path('test/data.txt');
    $signaturePath = public_path('test/signature_base64.sig');
    $publicKeyPath = public_path('test/public.pem');

    // Read the contents
    $data = file_get_contents($dataPath);
    $signature = base64_decode(file_get_contents($signaturePath)); // Decode the signature
    $publicKey = file_get_contents($publicKeyPath);

    // Verify the digital signature
    $result = $this->verifySignature($data, $signature, $publicKey);

    if ($result) {
        return response()->json(['success' => true, 'message' => 'Signature is valid']);
    } else {
        return response()->json(['success' => false, 'message' => 'Signature is invalid']);
    }
}

private function verifySignature($data, $signature, $publicKey)
{
    $publicKeyResource = openssl_pkey_get_public($publicKey);
    if ($publicKeyResource === false) {
        return false;
    }

    $result = openssl_verify($data, $signature, $publicKeyResource, OPENSSL_ALGO_SHA256);
    openssl_free_key($publicKeyResource);

    // Log error if verification fails
    if ($result === -1) {
        error_log(openssl_error_string());
        return false; // Signature verification failed
    }

    return $result === 1; // returns true if valid, false otherwise
}



}
