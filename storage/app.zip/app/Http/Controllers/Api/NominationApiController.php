<?php
namespace App\Http\Controllers\Api;
use App\Models\Document;
use App\Models\User;
use App\Models\Nomination;
use App\Models\NominationDetail;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NominationApiController extends Controller
{ 


public function storeNomination(Request $request)
{
   // Check if user exists
    $user = User::find($request->user_id);
    if (!$user) {
        return response()->json([
            'success' => false,
            'message' => 'User not found.',
        ], 404);
    }

    // Create a new Nomination
    $nomination = new Nomination([
        'state' => $request->state,
        'district' => $request->district,
        'taluka' => $request->taluka,
        'user_id' => $request->user_id,
        'position' => $request->position,
        'birth_date' => $request->birth_date,
        'join_date' => $request->join_date,
        'nomination_type' => $request->nomination_type,
    ]);
    
    // Save the nomination
    $nomination->save();

    // Prepare nominee details for insertion
    $nomineeDetails = [];
    foreach ($request->nominees as $nominee) {
        $nomineeDetails[] = [
            'nomination_id' => $nomination->id,
            'nominee_name' => $nominee['nominee_name'],
            'nominee_dob' => $nominee['nominee_dob'],
            'nominee_age' => $nominee['nominee_age'],
            'atypical_event' => $nominee['atypical_event'] ?? null,
            'relationship_nominee' => $nominee['relationship_nominee'] ?? null,
            'nominee_type' => $nominee['nominee_type'] ?? null,
            'nominee_amount' => $nominee['nominee_amount'] ?? null,
        ];
    }

    // Save the nominee details
    NominationDetail::insert($nomineeDetails);

    // Return a JSON response
    return response()->json([
        'success' => true,
        'message' => 'Nomination created successfully.',
        'data' => $nomination
    ], 201);
}
}
?>