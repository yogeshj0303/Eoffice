<?php

namespace App\Http\Controllers;

use App\Models\Checklist;
use App\Models\Tehsil;
use App\Models\Document;
use App\Models\Organization;
use Illuminate\Http\Request;

class ChecklistController extends Controller
{
    public function index()
    {
        $checklists = Checklist::all();
        return view('checklist-master.index', compact('checklists'));
    }
    
        public function tehshilIndex()
    {
        $tehshil = Tehsil::all();
        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 

        return view('checklist-master.tehshil', ['statesData' => $data, 'tehshil' => $tehshil]);
    }
    
        public function organizationIndex()
    {
        $organizations = Organization ::all();
        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 

        return view('checklist-master.organization', ['statesData' => $data, 'organizations' => $organizations ]);
    }
    
    public function DocumentIndex()
    {
        $documents = Document::all();
        return view('checklist-master.document', compact('documents'));
    }

    public function storeTehshil(Request $request)
    {
        $request->validate([
            'state' => 'required|string',
            'dist' => 'required|string',
            'tehshil_name' => 'required|string|max:255',
        ]);

        Tehsil::create([
            'state_name' => $request->state,
            'district_name' => $request->dist,
            'th_name' => $request->tehshil_name
        ]);

        return redirect()->back()->with('success', 'Tehsil added successfully.');
    }
      public function storeOrganization(Request $request)
    {
        $request->validate([
            'state' => 'required|string',
            'district' => 'required|string',
            'org_name' => 'required|string|max:255',
        ]);

        Organization::create([
            'state_name' => $request->state,
            'district_name' => $request->district,
            'org_name' => $request->org_name
        ]);

        return redirect()->back()->with('success', 'Organization added successfully.');
    }
      public function storeDocument(Request $request)
    {
        $request->validate([
            'doc_name' => 'required|string',
        ]);

        Document::create([
            'doc_name' => $request->doc_name,
        ]);

        return redirect()->back()->with('success', 'Document Name added successfully.');
    }

   public function destroyTehshil($id)
{
    $tehsil = Tehsil::findOrFail($id);
    $tehsil->delete();

    return response()->json(['success' => true]);
}
   public function destroyOrganization($id)
{
    $tehsil = Organization::findOrFail($id);
    $tehsil->delete();

    return response()->json(['success' => true]);
}

   public function destroyDocument($id)
{
    $tehsil = Document::findOrFail($id);
    $tehsil->delete();

         return response()->json(['success' => true]);
}

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $checklist = Checklist::create($request->all());

        return redirect()->route('checklists.index')->with('success', 'Checklist added successfully.');
    }

    public function edit($id)
    {
        $checklist = Checklist::findOrFail($id);
        return response()->json($checklist);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $checklist = Checklist::findOrFail($id);
        $checklist->update($request->all());

        return response()->json($checklist);
    }

    public function destroy($id)
    {
        $checklist = Checklist::findOrFail($id);
        $checklist->delete();

        return response()->json(['success' => true]);
    }
    
   
}
