<?php

namespace App\Http\Controllers;

use App\Models\ChecklistMaster;
use Illuminate\Http\Request;

class ChecklistmasterController extends Controller
{
    public function index()
    {
        $checklists = ChecklistMaster::all();
        return view('checklist-master.checklist', compact('checklists'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'checklist_name' => 'required|string|max:255',
        ]);

        ChecklistMaster::create($request->all());

        return redirect()->route('checklist-master.index')->with('success', 'Checklist added successfully.');
    }

    public function edit($id)
    {
        $checklist = ChecklistMaster::findOrFail($id);
        return response()->json($checklist);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'checklist_name' => 'required|string|max:255',
        ]);

        $checklist = ChecklistMaster::findOrFail($id);
        $checklist->update($request->all());

        return response()->json($checklist);
    }

    public function destroy($id)
    {
        $checklist = ChecklistMaster::findOrFail($id);
        $checklist->delete();

        return response()->json(['success' => true]);
    }
}
