<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Organization;

use Illuminate\Http\Request;

class DepartmentController extends Controller
{
public function index(Request $request)
{
    
       $departments = Department::select('departments.*', 'organizations.org_name')
        ->leftJoin('organizations', 'departments.organisation', '=', 'organizations.id') // left join to include all departments
        ->paginate(10); // Pagination applied here

     
        
              $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
  
        return view('departments.index', compact('departments') ,  ['statesData' => $data ]);
}


















    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        'state' => 'required|string|max:255',
            'district' => 'required|string|max:255',
            'taluka' => 'nullable|string|max:255',
     'organisation' => 'required|string|max:255',


        ]);

        $department = Department::create($request->all());

        return redirect()->route('departments.index')->with('success', 'Department added successfully.');
    }

    public function edit($id)
    {
        $department = Department::findOrFail($id);
        return response()->json($department);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $department = Department::findOrFail($id);
        $department->update($request->all());

        return response()->json($department);
    }

    public function destroy($id)
    {
        $department = Department::findOrFail($id);
        $department->delete();

        return response()->json(['success' => true]);
    }
    
    
    
       public function getTehsils(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Validate input
    if (!$state || !$district) {
        return response()->json([], 400); // Return empty array if validation fails
    }

    $tehsils = Tehsil::where('state_name', $state)
                     ->where('district_name', $district)
                     ->pluck('th_name');

    return response()->json($tehsils);
}











public function getOrganisations(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Debug to check if the state and district values are coming through
    \Log::info("State: " . $state . " District: " . $district);

    $organisations = Organization::where('state_name', $state)
                                  ->where('district_name', $district)
                                  ->get(['id', 'org_name']);

    if ($organisations->isEmpty()) {
        \Log::warning("No organisations found for State: " . $state . " and District: " . $district);
    }

    return response()->json($organisations);
}

}
