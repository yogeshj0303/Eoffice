<?php
namespace App\Http\Controllers;

use App\Models\Designation;
use App\Models\Department;

use Illuminate\Http\Request;

class DesignationController extends Controller
{
    public function index()
    {

        
        $designations = Designation::select('designations.*', 'organizations.org_name', 'departments.name as department_name')
    ->leftJoin('organizations', 'designations.organisation', '=', 'organizations.id')
    ->leftJoin('departments', 'designations.department_name', '=', 'departments.id') 
    ->paginate(10);


            $departments = Department::all();
  $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $statesData = json_decode($jsonData, true); 
        return view('designation.index', compact('designations' , 'departments','statesData'));
    }

   public function store(Request $request)
{
    $request->validate([
        'department_name' => 'required|string|max:255',
        'designation_name' => 'required|string|max:255',
                'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'nullable|string|max:255',
        'organisation' => 'required|string|max:255',

    ]);

    Designation::create([
        'department_name' => $request->department_name,
        'designation_name' => $request->designation_name,
                'state' => $request->state,
        'district' => $request->district,
        'taluka' => $request->taluka,
              'organisation' => $request->organisation,


    ]);

    return redirect()->route('designations.index')->with('success', 'Designation added successfully.');
}

    public function edit($id)
    {
        $designation = Designation::findOrFail($id);
        return response()->json($designation);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'department_name' => 'required|string|max:255',
            'designation_name' => 'required|string|max:255',
        ]);

        $designation = Designation::findOrFail($id);
        $designation->update($request->all());

        return response()->json($designation);
    }

    public function destroy($id)
    {
        $designation = Designation::findOrFail($id);
        $designation->delete();

        return response()->json(['success' => true]);
    }
    
    
    
    
    
    
    
       
       public function getTehsils(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Validate input
    if (!$state || !$district) {
        return response()->json([], 400); // Return empty array if validation fails
    }

    $tehsils = Tehsil::where('state_name', $state)
                     ->where('district_name', $district)
                     ->pluck('th_name');

    return response()->json($tehsils);
}











public function getOrganisations(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Debug to check if the state and district values are coming through
    \Log::info("State: " . $state . " District: " . $district);

    $organisations = Organization::where('state_name', $state)
                                  ->where('district_name', $district)
                                  ->get(['id', 'org_name']);

    if ($organisations->isEmpty()) {
        \Log::warning("No organisations found for State: " . $state . " and District: " . $district);
    }

    return response()->json($organisations);
}
    
    
    
    
    
    
    
public function getdepartment(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');
        $organisation = $request->input('organisation');



    $Department = Department::where('state', $state)
                                  ->where('district', $district)
                                ->where('organisation', $organisation)

                                  ->get(['id', 'name']);
                                  

    if ($Department->isEmpty()) {
        return response()->json([
            'message' => 'No data found',
            'state' => $state,
            'district' => $district,
            'organisation' => $organisation,
            'departments' => []
        ]);
    }

    return response()->json($Department);
}

    
 
 


public function getDesignation(Request $request)
{
    // Get the department_id from the request
    $department_id = $request->input('department_id'); // The value passed from frontend as department

    \Log::info("Department ID: " . $department_id);

    // Fetch designations where department_name holds the department ID
    $designations = Designation::where('department_name', $department_id) // department_name stores the ID here
                               ->get(['id', 'designation_name']); // Select id and designation_name

    return response()->json($designations);
}





    public function getDesignationsByTaluka(Request $request)
{
    $talukaId = $request->input('taluka_id');

    $designations = Designation::where('taluka', $talukaId)->get(['id', 'designation_name']);

    return response()->json($designations);
}

    
    
    
}
