<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; 
use App\Models\Tehsil;
use App\Models\Document; 
use App\Models\UserDocument; 
use Illuminate\Support\Facades\DB;




use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class DocumentController extends Controller
{


public function create(){
    
    
            $documents = Document::all(); 
              

    
    
      $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
      
    return view('document.add' , ['statesData' => $data ] , compact('documents'));
}



public function index(){
    
    
    

            $documents = DB::table('user_documents')
        ->join('users', 'user_documents.user_id', '=', 'users.id')
        ->select('user_documents.*', 'users.first_name as name')
        ->whereRaw('user_documents.id IN (SELECT MAX(id) FROM user_documents GROUP BY user_id)')
        ->get();


    
    
    return view('document.index' , compact('documents'));
}



public function show($id)
{
    $documents = DB::table('user_documents')
        ->where('user_id', $id)
        ->select('document_name', 'document_pdf')
        ->get();

    return view('document.show', compact('documents'));
}




public function fetchProfiles(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');
    $taluka = $request->input('taluka'); // Updated to use 'taluka'

    $users = User::where('state', $state)
                 ->where('district', $district)
                 ->where('taluka', $taluka)
                 ->get(['id', 'first_name', 'last_name']);

    // Return users in JSON format
    return response()->json($users);
}

    
    
    public function getTehsils(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Validate input
    if (!$state || !$district) {
        return response()->json([], 400); // Return empty array if validation fails
    }

    $tehsils = Tehsil::where('state_name', $state)
                     ->where('district_name', $district)
                     ->pluck('th_name');

    return response()->json($tehsils);
}


public function store(Request $request)
{
    $validator = Validator::make($request->all(), [
        'state' => 'required|string',
        'district' => 'required|string',
        'taluka' => 'required|string',
                        'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',


        'name' => 'required|string',
        'document-name.*' => 'required|string',
        'document-upload.*' => 'required|file|mimes:jpg,png,pdf,doc,docx|max:2048'
    ]);

    if ($validator->fails()) {
        return redirect()->back()->withErrors($validator)->withInput();
    }

    $documents = [];
    $documentNames = $request->input('document-name');
    $files = $request->file('document-upload');

    if ($files && $documentNames) {
        foreach ($files as $index => $file) {
            $filename = time() . '_document_' . $index . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('images'), $filename);

            $documents[] = [
                'user_id' => $request->input('name'),
                'state' => $request->input('state'),
                'district' => $request->input('district'),
                'taluka' => $request->input('taluka'),
                                'org_id' => $request->input('organisation'),
                'depart_id' => $request->input('department_name'),
                'design_id' => $request->input('designation'),

                'document_name' => $documentNames[$index],
                'document_pdf' => 'images/' . $filename
            ];
        }
    }

    UserDocument::insert($documents);

    return redirect()->back()->with('success', 'User details updated successfully!');
}



    public function destroy($id)
    {
        try {
            $UserDocument = UserDocument::findOrFail($id);

            $UserDocument->delete();

            return response()->json(['id' => $id, 'message' => 'Record deleted successfully.'], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'An error occurred while trying to delete the record.'], 500);
        }
    }





public function edit($userId)
{

    $documents = DB::table('user_documents')
        ->join('users', 'user_documents.user_id', '=', 'users.id')
        ->select('user_documents.*', 'users.first_name as name')
        ->where('user_documents.user_id', $userId)
        ->get();
        
        
                    $user = DB::table('user_documents')
        ->leftJoin('organizations', 'user_documents.org_id', '=', 'organizations.id')
                ->leftJoin('users', 'user_documents.user_id', '=', 'users.id')

        ->leftJoin('departments', 'user_documents.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'user_documents.design_id', '=', 'designations.id')
        ->where('user_documents.user_id', $userId)
        ->select(
            'user_documents.*',
            'users.*',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();


        
                        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 


    $documentTypes = [
        'PAN Card',
        'Aadhar Card',
        'Driving Licence',
    ];

    return view('document.edit', [
        'user' => $user,
            'statesData' => $data,

        'documents' => $documents,
        'documentTypes' => $documentTypes,
    ]);
}

public function update(Request $request, $userId)
{
    $validated = $request->validate([
        'state' => 'required|string',
        'district' => 'required|string',
        'taluka' => 'required|string',
        'profile_name' => 'required|string',
        'document_name.*' => 'required|string',
        'document_upload.*' => 'nullable|file|mimes:jpg,png,pdf|max:2048',
    ]);

    $user = User::findOrFail($userId);
    $user->update($validated);

    foreach ($request->document_ids as $index => $documentId) {
        $doc = UserDocument::findOrFail($documentId);
        $doc->document_name = $request->document_name[$index];
        
        if ($request->hasFile('document_upload.' . $index)) {
            $file = $request->file('document_upload.' . $index);
            $destinationPath = public_path('/images');
            $fileName = time() . '-' . $file->getClientOriginalName();
            $file->move($destinationPath, $fileName);
            $doc->document_pdf = 'images/' . $fileName;
        }

        $doc->save();
    }

    return redirect()->route('documents.index')->with('success', 'Documents updated successfully.');
}
















}