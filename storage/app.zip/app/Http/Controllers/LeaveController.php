<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Leave;
use App\Models\User;
use App\Models\leavetype;

use App\Models\Tehsil;
use Illuminate\Support\Facades\DB;


use Illuminate\Support\Facades\Http;


class LeaveController extends Controller
{
    
    public function create(){
        
        
        
         $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
       $leaves = leavetype::all();
   
        return view('user-leaves.add' , ['statesData' => $data] , compact('leaves'));
    }
    
    
    
   

    
    public function store(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'state' => 'required|string|max:255',
            'district' => 'required|string|max:255',
            'taluka' => 'required|string|max:255',
                                'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',

            'subject' => 'required|string|max:255',
            'description' => 'required|string',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
            'leave_days' => 'nullable',
            'available_leave' => 'required|in:yes,no',

            'apply_start_date' => 'required|date',
            'apply_end_date' => 'required|date',
            'approver' => 'nullable|string|max:255',
            'rejecter' => 'nullable|string|max:255',
            'reject_description' => 'nullable|string',
            'status' => 'required|string|in:Pending,Approved,Rejected',
        ]);

    $leave = Leave::create([
        'user_id' => $validatedData['name'],
        'state' => $validatedData['state'],
        'district' => $validatedData['district'],
        'taluka' => $validatedData['taluka'],
                'org_id' => $validatedData['organisation'],
        'depart_id' => $validatedData['department_name'],
        'design_id' => $validatedData['designation'],

        'subject' => $validatedData['subject'],
        'description' => $validatedData['description'],
        'start_date' => $validatedData['start_date'],
        'end_date' => $validatedData['end_date'],
                'leave_days' => $validatedData['leave_days'],
                'available_leave' => $validatedData['available_leave'],

        'apply_start_date' => $validatedData['apply_start_date'],
        'apply_end_date' => $validatedData['apply_end_date'],
        'approver' => $validatedData['approver'],
        'rejecter' => $validatedData['rejecter'],
        'reject_description' => $validatedData['reject_description'],
        'status' => $validatedData['status'],
    ]);


        // Redirect to a specific route or page with a success message
        return redirect()->route('leaves.index')->with('success', 'Leave added successfully.');
    }
    
    
    
        public function index()
    {
    $leaves = DB::table('leaves')
        ->join('users', 'leaves.user_id', '=', 'users.id')
        ->select('leaves.*', 'users.first_name as name')
        ->get();
        return view('user-leaves.index', compact('leaves'));
    }
    
    
    public function destroy($id)
{
    try {
        $leave = Leave::findOrFail($id);
        $leave->delete();
return response()->json(['success' => true, 'id' => $id]);
    } catch (\Exception $e) {
        return response()->json(['success' => false]);
    }
}


public function edit($id){
    
    
    
                $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 

        $leave = Leave::find($id);
        $leavetype = leavetype::all();
        
                    $user = DB::table('leaves')
        ->leftJoin('organizations', 'leaves.org_id', '=', 'organizations.id')
                ->leftJoin('users', 'leaves.user_id', '=', 'users.id')

        ->leftJoin('departments', 'leaves.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'leaves.design_id', '=', 'designations.id')
        ->where('leaves.id', $id)
        ->select(
            'leaves.*',
            'users.*',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

return view('user-leaves.edit', [
    'statesData' => $data,
    'user' => $user,
        'leavetype' => $leavetype

], compact('leave'));

}

public function update(Request $request, $id)
{
    
    
    
    
        $rules = [
        'user_id' => 'required|string|max:255',
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'required|string|max:255',
        'subject' => 'required|string|max:255',
        'description' => 'nullable|string',
        'start_date' => 'required|date',
        'end_date' => 'required|date|after_or_equal:start_date',
                    'leave_days' => 'nullable',
'available_leave' => 'required|in:yes,no',

        'apply_start_date' => 'nullable|date',
        'apply_end_date' => 'nullable|date|after_or_equal:apply_start_date',
        'approver' => 'nullable|string|max:255',
        'rejecter' => 'nullable|string|max:255',
        'reject_description' => 'nullable|string',
        'status' => 'required|in:Pending,Approved,Rejected',
    ];

    $request->validate($rules);


    $leave = Leave::find($id);
    if ($leave) {
        $leave->update($request->all());
        return redirect()->route('leaves.index')->with('success', 'Leave added successfully.');
    }
}


 public function updateStatus(Request $request, $id)
    {
     $validated =  $request->validate([
            'status' => 'required|string',
        ]);
        
        $leave = Leave::find($id);
        

        if (!$leave) {
        return redirect()->route('leaves.index')->with('success', 'Leave update no found .');
        }

        $leave->status = $request->status;
        $leave->save();

        return redirect()->route('leaves.index')->with('success', 'Leave added successfully.');
    }




public function fetchProfiles(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');
    $taluka = $request->input('taluka'); // Updated to use 'taluka'

    $users = User::where('state', $state)
                 ->where('district', $district)
                 ->where('taluka', $taluka)
                 ->get(['id', 'first_name', 'last_name']);

    // Return users in JSON format
    return response()->json($users);
}

    
    
    public function getTehsils(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Validate input
    if (!$state || !$district) {
        return response()->json([], 400); // Return empty array if validation fails
    }

    $tehsils = Tehsil::where('state_name', $state)
                     ->where('district_name', $district)
                     ->pluck('th_name');

    return response()->json($tehsils);
}























public function leavetype()
    {
        $leaves = leavetype::all();
        return view('user-leaves.leaves_type', compact('leaves'));
    }
    
       
    public function leavetypestore(Request $request)
    {
        $request->validate([
            'leave_type' => 'required|string|max:255',
        ]);

        $leaves = leavetype::create($request->all());

        return redirect()->route('leaves_type')->with('success', 'leave added successfully.');
    }

    public function leavetypeedit($id)
    {
        $leaves = leavetype::findOrFail($id);
        return response()->json($leaves);
    }

    public function leavetypeupdate(Request $request, $id)
    {
        $request->validate([
            'leave_type' => 'required|string|max:255',
        ]);

        $leaves = leavetype::findOrFail($id);
        $leaves->update($request->all());

        return response()->json($leaves);
    }

    public function leavetypedestroy($id)
    {
        $leaves = leavetype::findOrFail($id);
        $leaves->delete();

        return response()->json(['success' => true]);
    }
    




}
