<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;


class LocationController extends Controller
{
    
    
    
    
    public function getcountries(){
       $response =  Http::withHeaders([
            
            'api-token' => 'kOaCLCgcCqgqVqYbnN716m9dNYaUQ_JVuZhSPUF2YDVosSIG1c9mMAP2oUnM9DywPd0',
            'user-email' => 'pal021746@gmail.com'
            
            ])->get('https://www.universal-tutorial.com/api/getaccesstoken');
            
            
               
            
          $data =   (array)json_decode($response->body());
          
        $auth_token =   $data['auth_token'];
        
     $countryresponse =    Http::withHeaders([
            
                'Authorization' => 'Bearer '.$auth_token,
            
            ])->get('https://www.universal-tutorial.com/api/countries/');
        
        $countries = (array)json_decode($countryresponse->body());

        
        
        return view('user-profile.add');
    }
    
    
    
     public function getcountries(){
      $countryresponse =    Http::withHeaders([
            
                'Authorization' => 'Bearer '.$req->token,
            
            ])->get('https://www.universal-tutorial.com/api/states/'.$req->country);
        
        $states = (array)json_decode($stateresponse->body());
        return $states;
    
   
     }
   
   
}
