<?php

namespace App\Http\Controllers;

use App\Models\Newchecklist;
use App\Models\ChecklistMaster;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;


class NewChecklistController extends Controller
{
    public function create()
    {
                $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
    $checklistMasters = ChecklistMaster::all();

        return view('checklist-master.newchecklistadd' , ['statesData' => $data] , compact('checklistMasters'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'state' => 'required|string|max:255',
            'district' => 'required|string|max:255',
            'org_id' => 'required|integer',
            'depart_id' => 'required|integer',
            'taluka' => 'required|string|max:255',
            'design_id' => 'required|integer',
                'user_id' => 'required|integer',

            'checklist_name' => 'required|string',
'process_status' => 'required|in:yes,no',

            'page_no' => 'required|integer',
            'Status' => 'required|string|max:255',
            'page_file' => 'required|file|mimes:jpg,png,pdf|max:2048',
            'receipt_status' => 'nullable|string',
            'receipt_no' => 'nullable|string|max:255',
           
        ]);

           if ($request->hasFile('page_file')) {
            $file = $request->file('page_file');
            $destinationPath = public_path('/images');
            $fileName = time() . '-' . $file->getClientOriginalName();
            $file->move($destinationPath, $fileName);
            
              $validatedData['page_file'] = $fileName;
        }
        


        Newchecklist::create($validatedData);

        return redirect()->route('checklist-new.index')->with('success', 'Checklist created successfully!');
    }


                 
                 
                 public function index(){
                     
$checklists = DB::table('newchecklists')
    ->join('organizations', 'newchecklists.org_id', '=', 'organizations.id')
        ->join('departments', 'newchecklists.depart_id', '=', 'departments.id')
    ->join('designations', 'newchecklists.design_id', '=', 'designations.id')

    ->select('newchecklists.*', 'organizations.org_name' ,'departments.name' , 'designations.designation_name' )
    ->get();
    

                     
                     return view('checklist-master.newchecklist' , compact('checklists') );
                     
                     
                 }
                 
                 
                 
                    public function destroy($id)
{
    try {
        $checklist = Newchecklist::findOrFail($id);
        $checklist->delete();
        
        return response()->json(['id' => $id, 'success' => true, 'message' => 'Record deleted successfully.'], 200);
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'message' => 'An error occurred while trying to delete the record.'], 500);
    }
}





              public function edit($id){
                  
        $checklist = Newchecklist::findOrFail($id);
            $checklistMasters = ChecklistMaster::all();

            $user = DB::table('newchecklists')
        ->leftJoin('organizations', 'newchecklists.org_id', '=', 'organizations.id')
                ->leftJoin('users', 'newchecklists.user_id', '=', 'users.id')

        ->leftJoin('departments', 'newchecklists.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'newchecklists.design_id', '=', 'designations.id')
        ->where('newchecklists.id', $id)
        ->select(
            'newchecklists.*',
            'users.*',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();


        
                        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 

        return view('checklist-master.newchecklistedit' , compact('checklist' , 'checklistMasters' ) , ['statesData' => $data ,
        
                'user' => $user
]);
                  
              }


public function update(Request $request, $id)
{
    // Validate request data
    $validatedData = $request->validate([
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'org_id' => 'required|integer',
        'depart_id' => 'required|integer',
        'taluka' => 'required|string|max:255',
        'design_id' => 'required|integer',
        'checklist_name' => 'required|string',
        'process_status' => 'required|in:yes,no',
        'page_no' => 'required|integer',
        'Status' => 'required|string|max:255',
        'page_file' => 'nullable|file|mimes:jpg,png,pdf|max:2048',
        'receipt_status' => 'nullable|string',
        'receipt_no' => 'nullable|string|max:255',
    ]);

    $checklist = Newchecklist::findOrFail($id);

    if ($request->hasFile('page_file')) {
        $oldFile = $checklist->page_file;
        if ($oldFile && file_exists(public_path('/images/' . $oldFile))) {
            unlink(public_path('/images/' . $oldFile));
        }

        $file = $request->file('page_file');
        $destinationPath = public_path('/images');
        $fileName = time() . '-' . $file->getClientOriginalName();
        $file->move($destinationPath, $fileName);

        $validatedData['page_file'] = $fileName;
    } else {
        $validatedData['page_file'] = $checklist->page_file;
    }

    $checklist->update($validatedData);

    return redirect()->route('checklist-new.index')->with('success', 'Checklist updated successfully!');
}



}
