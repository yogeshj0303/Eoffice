<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Tehsil;
use App\Models\Nomination;
 use App\Models\Nominationtype;
use App\Models\NominationDetail;
use Illuminate\Support\Facades\DB;


use Illuminate\Support\Facades\Http;

class NominationController extends Controller
{
    // Display the list of users
    
       public function index()
{     
    
     $nominationsWithDetails = DB::table('nominations')
        ->join('users', 'nominations.user_id', '=', 'users.id')
        ->select('nominations.*', 'users.first_name as name')
        ->get();
   
    
          
   
    return view('nomination.index', compact('nominationsWithDetails'));
}

    
      public function create(){
          
          

        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
        
         $Nominationtype = Nominationtype::all();
          
        

        return view('nomination.create' , ['statesData' => $data ]  , compact('Nominationtype'));
    }
    
    
    public function show($id){
        
    $nominationsdetails = NominationDetail::where('nomination_id', $id)->get();
    
        
            return view('nomination.show', compact('nominationsdetails'));

        
        
    }
    

public function fetchProfiles(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');
    $taluka = $request->input('taluka'); // Updated to use 'taluka'

    $users = User::where('state', $state)
                 ->where('district', $district)
                 ->where('taluka', $taluka)
                 ->get(['id', 'first_name', 'last_name']);

    // Return users in JSON format
    return response()->json($users);
}

    
    
    public function getTehsils(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Validate input
    if (!$state || !$district) {
        return response()->json([], 400); // Return empty array if validation fails
    }

    $tehsils = Tehsil::where('state_name', $state)
                     ->where('district_name', $district)
                     ->pluck('th_name');

    return response()->json($tehsils);
}




public function getUserDetails($id)
{
    $user = User::find($id);
    
    
       if ($user) {
        return response()->json([
            // 'address' => $user->address,
            // 'address_B' => $user->address_B,
            // 'caste' => $user->caste,
            // 'father_name' => $user->father_name,
            // 'father_address' => $user->father_address,
    'birth_date' => $user->birth_date->format('Y-m-d'), 
            'birth_text' => $user->birth_text,
//             'height' => $user->height,
//             'birth_mark' => $user->birth_mark,
//             'qualification' => $user->qualification,
//             'another_qualification' => $user->another_qualification,
            
//             'digital_sig' => $user->digital_sig ? url( $user->digital_sig) : null,
// 'digital_sig_verify' => $user->digital_sig_verify ? url($user->digital_sig_verify) : null,
// 'certificate_no' => $user->certificate_no,
// 'post_name' => $user->post_name ? url('images/' . $user->post_name) : null,

            
        ]);
        
        
       }
 else {
        return response()->json(['error' => 'User not found'], 404);
    }
}








  public function store(Request $request)
{
 $validatedata = $request->validate([
    'state' => 'required|string',
    'district' => 'required|string',
    'taluka' => 'required|string',
                    'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',

    'name' => 'required|string',
    'position' => 'required|string',
    'birth_date' => 'required|date',
    'join_date' => 'required|date',
    'nomination_type' => 'required|string',
    'digital_sig_user' => 'required|file|mimes:jpg,png,pdf',
    'digital_sig_clerk' => 'required|file|mimes:jpg,png,pdf',
    'digital_sig_head' => 'required|file|mimes:jpg,png,pdf',
    'witness_sig_one' => 'required|file|mimes:jpg,png,pdf',
    'witness_sig_two' => 'required|file|mimes:jpg,png,pdf',
    'nominee_name.*' => 'required|string',
    'nominee_dob.*' => 'required|date',
    'nominee_age.*' => 'required|integer',
    'atypical_event.*' => 'required|string',
    'relationship_nominee.*' => 'required|string',
    'nominee_type.*' => 'required|string',
    'nominee_amount.*' => 'required|string',
]);

$nomination = new Nomination([
    'state' => $request->state,
    'district' => $request->district,
    'taluka' => $request->taluka,
                    'org_id' => $request->organisation, 
        'depart_id' => $request->department_name,
        'design_id' => $request->designation,

    'user_id' => $request->name,
    'position' => $request->position,
    'birth_date' => $request->birth_date,
    'join_date' => $request->join_date,
    'nomination_type' => $request->nomination_type,
]);

// Handle file uploads
if ($request->hasFile('digital_sig_user') && $request->file('digital_sig_user')->isValid()) {
    $file1 = $request->file('digital_sig_user');
    $filename1 = time() . '_digital_sig_user.' . $file1->getClientOriginalExtension();
    $file1->move(public_path('images'), $filename1);
    $nomination->digital_sig_user = 'images/' . $filename1;
}

if ($request->hasFile('digital_sig_clerk') && $request->file('digital_sig_clerk')->isValid()) {
    $file2 = $request->file('digital_sig_clerk');
    $filename2 = time() . '_digital_sig_clerk.' . $file2->getClientOriginalExtension();
    $file2->move(public_path('images'), $filename2);
    $nomination->digital_sig_clerk = 'images/' . $filename2;
}

if ($request->hasFile('digital_sig_head') && $request->file('digital_sig_head')->isValid()) {
    $file3 = $request->file('digital_sig_head');
    $filename3 = time() . '_digital_sig_head.' . $file3->getClientOriginalExtension();
    $file3->move(public_path('images'), $filename3);
    $nomination->digital_sig_head = 'images/' . $filename3;
}

if ($request->hasFile('witness_sig_one') && $request->file('witness_sig_one')->isValid()) {
    $file4 = $request->file('witness_sig_one');
    $filename4 = time() . '_witness_sig_one.' . $file4->getClientOriginalExtension();
    $file4->move(public_path('images'), $filename4);
    $nomination->witness_sig_one = 'images/' . $filename4;
}

if ($request->hasFile('witness_sig_two') && $request->file('witness_sig_two')->isValid()) {
    $file5 = $request->file('witness_sig_two');
    $filename5 = time() . '_witness_sig_two.' . $file5->getClientOriginalExtension();
    $file5->move(public_path('images'), $filename5);
    $nomination->witness_sig_two = 'images/' . $filename5;
}

// Save the nomination data along with the file paths
$nomination->save();


if (!empty($request->nominee_name)) {
    foreach ($request->nominee_name as $index => $nomineeName) {
        $nominationDetail = new NominationDetail([
            'nomination_id' => $nomination->id,
            'nominee_name' => $nomineeName,
            'nominee_dob' => $request->nominee_dob[$index] ?? null,
            'nominee_age' => $request->nominee_age[$index] ?? null,
            'atypical_event' => $request->atypical_event[$index] ?? null,
            'relationship_nominee' => $request->relationship_nominee[$index] ?? null,
            'nominee_type' => $request->nominee_type[$index] ?? null,
            'nominee_amount' => $request->nominee_amount[$index] ?? null,
        ]);

        $nominationDetail->save();
    }

    return redirect()->route('nomination-index')->with('success', 'Nomination created successfully.');
}



}


    public function destroy($id)
    {
        try {
            $nomination = Nomination::findOrFail($id);
        NominationDetail::where('nomination_id', $nomination->id)->delete();

            $nomination->delete();

            return response()->json(['id' => $id, 'message' => 'Record deleted successfully.'], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'An error occurred while trying to delete the record.'], 500);
        }
    }











    public function edit($id)
    
    
    {
        
$nomination = DB::table('nominations')
    ->join('users', 'nominations.user_id', '=', 'users.id')
    ->select('nominations.*', 'users.first_name as name')
    ->where('nominations.id', $id)
    ->first(); 
    
    
    
    
    
    
    
            
                    $user = DB::table('nominations')
        ->leftJoin('organizations', 'nominations.org_id', '=', 'organizations.id')
                ->leftJoin('users', 'nominations.user_id', '=', 'users.id')

        ->leftJoin('departments', 'nominations.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'nominations.design_id', '=', 'designations.id')
        ->where('nominations.id', $id)
        ->select(
            'nominations.*',
            'users.*',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();
         $Nominationtype = Nominationtype::all();


        
                        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 


           $nomination->birth_date = \Carbon\Carbon::parse($nomination->birth_date)->format('Y-m-d');
$nomination->join_date = \Carbon\Carbon::parse($nomination->join_date)->format('Y-m-d');

               
        
    $nominationDetails = NominationDetail::where('nomination_id', $id)->get();


        
        
        
    return view('nomination.edit', [
        'user' => $user,
            'statesData' => $data,

        'nomination' => $nomination,
        'nominationDetails' => $nominationDetails,
        'Nominationtype' => $Nominationtype,
    ]);
    
    
    
    }
    
    
    
    
    

 public function update(Request $request, $id)
{
    $validatedData = $request->validate([
        'position' => 'required|string|max:255',
        'birth_date' => 'required|date',
        'join_date' => 'required|date',
        'nomination_type' => 'required|string|in:GPF,NPS',
        'nominee_name.*' => 'required|string|max:255',
        'nominee_dob.*' => 'required|date',
        'nominee_age.*' => 'required|integer|min:0',
        'atypical_event.*' => 'nullable|string|max:255',
        'relationship_nominee.*' => 'nullable|string|max:255',
        'nominee_type.*' => 'required|string|in:Main,Sub',
        'nominee_amount.*' => 'required|string|max:255',
    ]);
    
    // Find the nomination record by ID
    $nomination = Nomination::findOrFail($id);

    // Update the nomination fields
    $nomination->update([
        'position' => $request->input('position'),
        'birth_date' => $request->input('birth_date'),
        'join_date' => $request->input('join_date'),
        'nomination_type' => $request->input('nomination_type'),
    ]);

    // Update each nominee's details
    foreach ($request->input('nominee_name') as $index => $name) {
        $nominationDetail = NominationDetail::find($request->input('nominee_id')[$index]);
        if ($nominationDetail) {
            $nominationDetail->update([
                'nominee_name' => $name,
                'nominee_dob' => $request->input('nominee_dob')[$index],
                'nominee_age' => $request->input('nominee_age')[$index],
                'atypical_event' => $request->input('atypical_event')[$index],
                'relationship_nominee' => $request->input('relationship_nominee')[$index],
                'nominee_type' => $request->input('nominee_type')[$index],
                'nominee_amount' => $request->input('nominee_amount')[$index],
            ]);
        }
    }

    // Redirect back with a success message
    return redirect()->route('nomination-index')->with('success', 'Nomination updated successfully!');
}















public function nominationtype()
    {
        $nominations = Nominationtype::all();
        return view('nomination.nomination_type', compact('nominations'));
    }
    
       
    public function nominationstore(Request $request)
    {
        $request->validate([
            'nomination_type' => 'required|string|max:255',
        ]);

        $nominations = Nominationtype::create($request->all());

        return redirect()->route('nomination_type')->with('success', 'leave added successfully.');
    }

    public function nominationedit($id)
    {
        $nominations = Nominationtype::findOrFail($id);
        return response()->json($nominations);
    }

    public function nominationupdate(Request $request, $id)
    {
        $request->validate([
            'nomination_type' => 'required|string|max:255',
        ]);

        $nominations = Nominationtype::findOrFail($id);
        $nominations->update($request->all());

        return response()->json($nominations);
    }

    public function nominationdestroy($id)
    {
        $nominations = Nominationtype::findOrFail($id);
        $nominations->delete();

        return response()->json(['success' => true]);
    }
    




}

