<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\User;
use Illuminate\Http\Request;

class OrganizationLoginController extends Controller
{
    public function index()
    {
        $users = User::where('is_admin','organization')->orderBy('id','DESC')->get();
      
        return view('organization-login.index', compact('users'));
    }
    
    public function create(){
         $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $statesData = json_decode($jsonData, true); 
        return view('organization-login.create', compact('statesData'));
    }

 public function store(Request $request)
{
    // Validate form data
    $request->validate([
        'state' => 'required|string|max:255',
            'district' => 'required|string|max:255',
            'taluka' => 'nullable|string|max:255',
                'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',

        'first_name' => 'required|string|max:255',
        'middle_name' => 'nullable|string|max:255',
        'last_name' => 'required|string|max:255',
        'email' => 'required|email|max:255',
        'number' => 'required|numeric|digits:10',
        'username' => 'required|string|max:255|unique:users,username',
        'password' => 'required|string|min:8',
        'address' => 'required|string|max:255',
        'profile_pic' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Validate the profile picture
    ]);

    // Handle file upload
     if ($request->hasFile('profile_pic')) {
            $file = $request->file('profile_pic');
            $destinationPath = public_path('/images');
            $fileName = time() . '-' . $file->getClientOriginalName();
            $file->move($destinationPath, $fileName);
         
        }

    // Save the user data to the database
    $user = new User();
      $user->state = $request->state;
        $user->district = $request->district;
          $user->taluka = $request->taluka;
                              $user->org_id = $request->organisation;
          $user->depart_id = $request->department_name;
          $user->design_id = $request->designation;

    $user->first_name = $request->first_name;
    $user->middle_name = $request->middle_name;
    $user->last_name = $request->last_name;
    $user->email = $request->email;
    $user->number = $request->number;
    $user->username = $request->username;
    $user->password = bcrypt($request->password);
    $user->address = $request->address;
      $user->is_admin = "organization";
    $user->profile_pic = $fileName; // Save the path of the profile picture
    $user->save();

    return redirect()->route('organization.index')->with('success', 'Organization added successfully!');
}

    public function edit($id)
    {
        $department = User::findOrFail($id);
        return response()->json($department);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $department = User::findOrFail($id);
        $department->update($request->all());

        return response()->json($department);
    }

    public function destroy($id)
    {
        $department = User::findOrFail($id);
        $department->delete();

        return response()->json(['success' => true]);
    }
}
