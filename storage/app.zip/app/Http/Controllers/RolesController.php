<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\User;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RolesController extends Controller
{
    public function index()
{
    // Fetch roles with their related organisation, department, and designation details
    $roles = Role::leftJoin('organizations', 'roles.organisation', '=', 'organizations.id')
                 ->leftJoin('departments', 'roles.department_name', '=', 'departments.id')
                 ->leftJoin('designations', 'roles.designation', '=', 'designations.id')
                 ->select('roles.*', 'organizations.org_name as organisation_name','organizations.state_name','organizations.district_name' ,'departments.name as department_name', 'designations.designation_name as designation_name')
                 ->paginate(5);
                 
    return view('organization-login.add-role.index', compact('roles'));
}
    
    public function create(){
         $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $statesData = json_decode($jsonData, true); 
        return view('organization-login.add-role.add-role', compact('statesData'));
    }

 public function store(Request $request)
{
    
    // Validate the form data
    $request->validate([
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'nullable|string|max:255',
        'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',
        'role_name' => 'required|string|max:255',
    ]);

    // Save the role data to the database
    $role = new Role();
    $role->state = $request->state;
    $role->district = $request->district;
    $role->taluka = $request->taluka;
    $role->organisation = $request->organisation;  // Updated to match DB column
    $role->department_name = $request->department_name;  // Updated to match DB column
    $role->designation = $request->designation;  // Updated to match DB column
    $role->role_name = $request->role_name;

    $role->save();

    return redirect()->route('roles.index')->with('success', 'Role added successfully!');
}


    public function edit($id)
{
    $role = Role::findOrFail($id);

   $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true); 

    $user = DB::table('roles')
        ->leftJoin('organizations', 'roles.organisation', '=', 'organizations.id')
        ->leftJoin('departments', 'roles.department_name', '=', 'departments.id')
        ->leftJoin('designations', 'roles.designation', '=', 'designations.id')
        ->where('roles.id', $id)
        ->select(
            'roles.*',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

    return view('organization-login.add-role.edit', [
        
        'statesData' => $data,
        'user' => $user,
        'role' => $role
    ]);  
}


    public function update(Request $request, $id)
    {
       $validated =     $request->validate([
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'nullable|string|max:255',
        'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',
        'role_name' => 'required|string|max:255',
    ]);
    $user = Role::find($id);

    $user->update($validated);

    return redirect()->route('roles.index')->with('success', 'Role added successfully!');
    }

public function destroy($id)
{
    Role::findOrFail($id)->delete();

    return response()->json(['message' => 'Role deleted successfully']);
}

public function destroyMultiple(Request $request)
{
    $ids = $request->input('ids');
    if (empty($ids)) {
        return response()->json(['message' => 'No roles selected'], 400);
    }

    Role::whereIn('id', $ids)->delete();

    return response()->json(['message' => 'Selected roles deleted successfully']);
}


}
