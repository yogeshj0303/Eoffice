<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\User;
use App\Models\Role;
use App\Models\RolePermission;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class RolesPermission extends Controller
{
    public function index()
{
    // Fetch roles with their related organisation, department, and designation details
    $rolepermissions = RolePermission::leftJoin('roles', 'role_permissions.role_name', '=', 'roles.id')
    ->leftJoin('organizations', 'roles.organisation', '=', 'organizations.id')
    ->leftJoin('departments', 'roles.department_name', '=', 'departments.id')
    ->leftJoin('designations', 'roles.designation', '=', 'designations.id')
    ->select(
        'role_permissions.*',
        'roles.role_name',  // Select fields from roles table
        'organizations.org_name as organisation_name',
        'organizations.state_name',
        'organizations.district_name',
        'departments.name as department_name',
        'designations.designation_name as designation_name'
    )
    ->paginate(5);
      
    return view('organization-login.assign-permission.Permission-index', compact('rolepermissions'));
}
    
    public function create(){
        $roles=Role::get();
         $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $statesData = json_decode($jsonData, true); 
        return view('organization-login.assign-permission.index', compact('statesData','roles'));
    }
public function getRoles(Request $request) {
    $roles = Role::where('state', $request->state)
                 ->where('district', $request->district)
                 
                 ->where('organisation', $request->organisation)
                 ->where('department_name', $request->department_name)
                 ->where('designation', $request->designation)
                 ->get();

    return response()->json($roles);
}



public function store(Request $request)
    {
        // Validate the required fields
        $validator = Validator::make($request->all(), [
            'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'nullable|string|max:255',
        'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',
        'role_name' =>  'required|integer|exists:roles,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }

        // Prepare the data for creation
        $data = $request->only(['state', 'district', 'organisation', 'department_name', 'designation', 'role_name']);

        // Define the permission types
        $permissions = ['view', 'create', 'edit', 'delete'];

        // Loop through each permission type and set default values
        foreach ($permissions as $permission) {
            $data["dashborad_$permission"] = $request->input("dashborad_$permission", 1);
            $data["department_$permission"] = $request->input("department_$permission", 1);
            $data["designation_$permission"] = $request->input("designation_$permission", 1);
            $data["organization_$permission"] = $request->input("organization_$permission", 1);
            $data["staff_$permission"] = $request->input("staff_$permission", 1);
            $data["role_$permission"] = $request->input("role_$permission", 1);
            $data["permission_$permission"] = $request->input("permission_$permission", 1);
            $data["report_$permission"] = $request->input("report_$permission", 1);
            $data["userprofile_$permission"] = $request->input("userprofile_$permission", 1);
            $data["userdetail_$permission"] = $request->input("userdetail_$permission", 1);
            $data["document_$permission"] = $request->input("document_$permission", 1);
            $data["leave_$permission"] = $request->input("leave_$permission", 1);
            $data["nomination_$permission"] = $request->input("nomination_$permission", 1);
            $data["salary_$permission"] = $request->input("salary_$permission", 1);
            $data["checklist_$permission"] = $request->input("checklist_$permission", 1);
            $data["trans_join_$permission"] = $request->input("trans_join_$permission", 1);
        }

        // Create the RolePermission entry
        $rolePermission = RolePermission::create($data);

        return redirect()->route('rolespermission.index')->with('success', 'Role Permission added successfully!');
    }


public function edit($id)
{
    $rolePermission = RolePermission::findOrFail($id);
    // Fetch the states and districts data from the JSON file
    $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true);

    // Fetch role permissions and related data with joins
    $user = DB::table('role_permissions')
        ->leftJoin('roles', 'role_permissions.role_name', '=', 'roles.id')
        ->leftJoin('organizations', 'roles.organisation', '=', 'organizations.id')
        ->leftJoin('departments', 'roles.department_name', '=', 'departments.id')
        ->leftJoin('designations', 'roles.designation', '=', 'designations.id')
        ->where('role_permissions.id', $id)
        ->select('role_permissions.id',
            'role_permissions.*',
            'roles.role_name',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

    // Return the view with the required data
    return view('organization-login.assign-permission.edit', [
        'statesData' => $data,
        'user' => $user,
        'rolePermission' => $rolePermission
    ]);
}

public function show($id)
{
    $rolePermission = RolePermission::findOrFail($id);
    // Fetch the states and districts data from the JSON file
    $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true);

    // Fetch role permissions and related data with joins
    $user = DB::table('role_permissions')
        ->leftJoin('roles', 'role_permissions.role_name', '=', 'roles.id')
        ->leftJoin('organizations', 'roles.organisation', '=', 'organizations.id')
        ->leftJoin('departments', 'roles.department_name', '=', 'departments.id')
        ->leftJoin('designations', 'roles.designation', '=', 'designations.id')
        ->where('role_permissions.id', $id)
        ->select('role_permissions.id',
            'role_permissions.*',
            'roles.role_name',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

    // Return the view with the required data
    return view('organization-login.assign-permission.view', [
        'statesData' => $data,
        'user' => $user,
        'rolePermission' => $rolePermission
    ]);
}




   public function update(Request $request, $id)
{
    // Validate the required fields
    $validator = Validator::make($request->all(), [
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'nullable|string|max:255',
        'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',
        'role_name' =>  'required|integer|exists:roles,id',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'errors' => $validator->errors()
        ], 422);
    }

    // Find the RolePermission entry
    $rolePermission = RolePermission::findOrFail($id);

    // Prepare the data for update
    $data = $request->only(['state', 'district', 'organisation', 'department_name', 'designation', 'role_name']);

    // Define the permission types
    $permissions = ['view', 'create', 'edit', 'delete'];

    // Loop through each permission type and set values
    foreach ($permissions as $permission) {
        $data["dashborad_$permission"] = $request->input("dashborad_$permission", 1);
        $data["department_$permission"] = $request->input("department_$permission", 1);
        $data["designation_$permission"] = $request->input("designation_$permission", 1);
        $data["organization_$permission"] = $request->input("organization_$permission", 1);
        $data["staff_$permission"] = $request->input("staff_$permission", 1);
        $data["role_$permission"] = $request->input("role_$permission", 1);
        $data["permission_$permission"] = $request->input("permission_$permission", 1);
        $data["report_$permission"] = $request->input("report_$permission", 1);
        $data["userprofile_$permission"] = $request->input("userprofile_$permission", 1);
        $data["userdetail_$permission"] = $request->input("userdetail_$permission", 1);
        $data["document_$permission"] = $request->input("document_$permission", 1);
        $data["leave_$permission"] = $request->input("leave_$permission", 1);
        $data["nomination_$permission"] = $request->input("nomination_$permission", 1);
        $data["salary_$permission"] = $request->input("salary_$permission", 1);
        $data["checklist_$permission"] = $request->input("checklist_$permission", 1);
        $data["trans_join_$permission"] = $request->input("trans_join_$permission", 1);
    }

    // Update the RolePermission entry
    $rolePermission->update($data);

    return redirect()->route('rolespermission.index')->with('success', 'Role Permission updated successfully!');
}


public function destroy($id)
{
    RolePermission::findOrFail($id)->delete();

    return response()->json(['message' => 'Permission deleted successfully']);
}

public function destroyMultiple(Request $request)
{
    $ids = $request->input('ids');
    if (empty($ids)) {
        return response()->json(['message' => 'No roles selected'], 400);
    }

    Role::whereIn('id', $ids)->delete();

    return response()->json(['message' => 'Selected roles deleted successfully']);
}


}
