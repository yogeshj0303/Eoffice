<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Designation;

use App\Models\Salary;
use App\Models\Organization;
use App\Models\User;


use Illuminate\Http\Request;

class SalaryController extends Controller
{
     public function index()
    {
        $salary = Salary::all();
     
        
        return view('salary.index', compact('salary'));
    }
      public function indexDetails()
    {
           $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $statesData = json_decode($jsonData, true); 
  
        
        return view('salary.create-salary-details', compact('statesData'));
    }
    public function create()
    {
   
              $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
  
        
        return view('salary.create',['statesData' => $data ]);
    }
public function store(Request $request)
{
    $validate = $request->validate([
        'name' => 'required|integer',
        'state' => 'required|string',
        'district' => 'required|string',
        'taluka' => 'required|string',
        'org_id' => 'required|integer',
        'depart_id' => 'required|integer',
        'design_id' => 'required|integer',
        'salary_type' => 'required|string',
        'starting_salary' => 'required',
        'joining_date' => 'required|date',
        'salary' => 'required',
        'designation' => 'required|string',
        'promotion_state' => 'required',
        'promotion_district' => 'required',
        'promotion_org_id' => 'required',
        'promotion_depart_id' => 'required',
        'promotion_taluka' => 'required',
        'promotion_design_id' => 'required',

        'increment_type'  => 'required|string',
        'increment_name'  => 'required|string',
        'description'  => 'required|string',
        'additional_document' => 'required|file|mimes:jpeg,png,pdf',
        'increment_date'  => 'required|date',
        'salary_calculation_type'  => 'required|string',
        'additional_salary'  => 'required|integer',

        'clerk_dig_sig' => 'nullable|file|mimes:jpeg,png,pdf',
        'hod_dig_sig' => 'nullable|file|mimes:jpeg,png,pdf',
        'user_dig_sig' => 'nullable|file|mimes:jpeg,png,pdf',
    ]);

    $endYearSalary = $this->calculateEndYearSalary($request->name);
    $salaryToStore = $request->salary < $endYearSalary ? $endYearSalary : $request->salary;

    $salary = Salary::where('user_id', $request->name)->first();

    if ($salary) {
        // Check if the existing record's status is 'complete'
        if ($salary->status === 'complete') {
            return redirect()->back()->with('error', 'This user record is already complete.');
        }

        // Handle file uploads
        $filePaths = [];
        $files = [
            'clerk_dig_sig' => $request->file('clerk_dig_sig'),
            'hod_dig_sig' => $request->file('hod_dig_sig'),
            'user_dig_sig' => $request->file('user_dig_sig'),
            'additional_document' => $request->file('additional_document'),


        ];

        foreach ($files as $key => $file) {
            if ($file) {
                $filePath = $file->move(public_path('images'), $file->getClientOriginalName());
                $filePaths[$key] = 'images/' . $file->getClientOriginalName();
            }
        }

        $salary->update(array_merge($filePaths, $request->except(['clerk_dig_sig', 'hod_dig_sig', 'user_dig_sig'])));

        $allFilesPresent = $salary->clerk_dig_sig && $salary->hod_dig_sig && $salary->user_dig_sig;
        if ($allFilesPresent) {
            $salary->status = 'complete';
            $salary->save();
        }

        return redirect()->back()->with('success', 'Salary record updated successfully.');
    } else {
        // Handle file uploads for a new record
        $filePaths = [];
        $files = [
            'clerk_dig_sig' => $request->file('clerk_dig_sig'),
            'hod_dig_sig' => $request->file('hod_dig_sig'),
            'user_dig_sig' => $request->file('user_dig_sig'),
        ];

        foreach ($files as $key => $file) {
            if ($file) {
                $filePath = $file->move(public_path('images'), $file->getClientOriginalName());
                $filePaths[$key] = 'images/' . $file->getClientOriginalName();
            }
        }

        $status = 'pending';
        if ($request->hasFile('clerk_dig_sig') && $request->hasFile('hod_dig_sig') && $request->hasFile('user_dig_sig')) {
            $status = 'complete';
        }

        Salary::create(array_merge(
            $request->except(['clerk_dig_sig', 'hod_dig_sig', 'user_dig_sig']),
            ['user_id' => $request->input('name')],
            ['promotion_salary' =>  $salaryToStore],
            ['status' => $status],
            $filePaths
        ));

        return redirect()->back()->with('success', 'Salary record created successfully.');
    }
}

private function calculateEndYearSalary($userId)
{
    $user = User::find($userId);
    $currentSalary = $user->joining_start_salary;
    $joiningYear = date('Y', strtotime($user->joining_date));
    $promotionYears = ($user->salary_type == 'education') ? 10 : 12;

    // Apply salary increment for each year starting from the joining year
    for ($year = 1; $year <= $promotionYears; $year++) {
        $currentSalary += $currentSalary * 0.03;
    }

    return $currentSalary;
}

    public function edit($id)
    {
        $salary = Salary::findOrFail($id);
        return response()->json($salary);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $department = Department::findOrFail($id);
        $department->update($request->all());

        return response()->json($department);
    }

    public function destroy($id)
    {
        $department = Salary::findOrFail($id);
        $department->delete();

        return response()->json(['success' => true]);
    }
    
    
    
       public function getTehsils(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Validate input
    if (!$state || !$district) {
        return response()->json([], 400); // Return empty array if validation fails
    }

    $tehsils = Tehsil::where('state_name', $state)
                     ->where('district_name', $district)
                     ->pluck('th_name');

    return response()->json($tehsils);
}











public function getOrganisations(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Debug to check if the state and district values are coming through
    \Log::info("State: " . $state . " District: " . $district);

    $organisations = Organization::where('state_name', $state)
                                  ->where('district_name', $district)
                                  ->get(['id', 'org_name']);

    if ($organisations->isEmpty()) {
        \Log::warning("No organisations found for State: " . $state . " and District: " . $district);
    }

    return response()->json($organisations);
}


















public function showSalaryDetailsPage(Request $request)
{
    
            $showPromotionCard = false; // Flag to hide the card

    $data = $request->all();
               $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $statesData = json_decode($jsonData, true);
        
            $organization = Organization::where('id', $data['org_id'])->first();
    $data['org_id'] = $organization ? $organization->id : 'N/A';
        $org_name = $organization ? $organization->org_name : 'N/A'; // org_name

    
        if (isset($data['department_name'])) {
        $department = Department::where('id', $data['department_name'])->first();
        $data['department_name'] = $department ? $department->id : 'N/A';
            $department_name = $department ? $department->name : 'N/A';

    }

    if (isset($data['designation'])) {
        $designation = Designation::where('id', $data['designation'])->first();
        $data['designation'] = $designation ? $designation->id : 'N/A';
                $designation = $designation ? $designation->designation_name : 'N/A';

    }

    if (isset($data['name'])) {
        $profile = User::where('id', $data['name'])->first();
        $data['name'] = $profile ? $profile->id : 'N/A';
            $name = $profile ? $profile->first_name : 'N/A';

    }
    
    
        $salary = Salary::where('user_id', $data['name'])->first();
            $salaryCalculationType = optional($salary)->salary_calculation_type;

        $additionalSalary = optional($salary)->additional_salary ?? 0; 
        $increment_date = optional($salary)->increment_date ?? 0;
       
       
       
                     
       

    if ($salary && strtolower($salary->Status) === 'pending') {
            $salaryDetails = array_merge(
                $salary->toArray(), 
                ['Status' => 'complete'] 
            );
                        $showPromotionCard = true; 

        } else {
            $salaryDetails = [
                'promotion_salary' => $salary ? $salary->promotion_salary : null,
                'clerk_dig_sig' => $salary ? $salary->clerk_dig_sig : null,
                'hod_dig_sig' => $salary ? $salary->hod_dig_sig : null,
                'user_dig_sig' => $salary ? $salary->user_dig_sig : null,

            ];
        }
        
        if($salary){
$designation_name = optional(Designation::where('id', $salary->designation)->first())->designation_name;
        }
        else{
            $designation_name = NULL;
        }
        


    $designations = Designation::all();

    return view('salary.create-salary-details', compact('data' , 'statesData' , 'designations' , 'org_name' , 'name' , 'designation'  , 'department_name' , 'salaryDetails' , 'showPromotionCard' , 'additionalSalary' , 'designation_name' ,  'increment_date' , 'salaryCalculationType'));
}








public function storePromotion(Request $request)
{
    $request->validate([
        'designation' => 'required|string',
        'salary' => 'required|string',
        'clerk_digital_sig' => 'required|file|mimes:jpeg,png,pdf|max:2048',
        'hod_digital_sig' => 'required|file|mimes:jpeg,png,pdf|max:2048',
        'user_digital_sig' => 'required|file|mimes:jpeg,png,pdf|max:2048',
    ]);

    $request->session()->put('promotion_data', [
        'designation' => $request->input('designation'),
        'salary' => $request->input('salary'),
        'clerk_digital_sig' => $request->file('clerk_digital_sig')->store('signatures'),
        'hod_digital_sig' => $request->file('hod_digital_sig')->store('signatures'),
        'user_digital_sig' => $request->file('user_digital_sig')->store('signatures'),
    ]);

    return response()->json(['success' => true]);
}


}
