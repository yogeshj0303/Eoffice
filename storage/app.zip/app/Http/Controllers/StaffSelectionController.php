<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\User;
use App\Models\Role;
use App\Models\Staff;
use App\Models\RolePermission;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Carbon\Carbon;

class StaffSelectionController extends Controller
{
   public function index()
{
    // Fetch staffs with their related organisation, department, designation, and role details
    $staffs = Staff::leftJoin('organizations', 'staffs.organisation_id', '=', 'organizations.id')
        ->leftJoin('departments', 'staffs.department_id', '=', 'departments.id')
        ->leftJoin('designations', 'staffs.designation_id', '=', 'designations.id')
        ->leftJoin('roles', 'staffs.role_name', '=', 'roles.id')
        ->select(
            'staffs.*', // Select all fields from the staffs table
            'organizations.org_name',
            'organizations.state_name',
            'organizations.district_name',
            'departments.name',
            'designations.designation_name',
            'roles.role_name as role_name'
        )
        ->paginate(5); // Paginate the result set

    // Return the view and pass the staff data
    return view('organization-login.staff-selection.index', compact('staffs'));
}

    
    public function create(){
        
         $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $statesData = json_decode($jsonData, true); 
        return view('organization-login.staff-selection.add', compact('statesData'));
    }
public function getRoles(Request $request) {
    $roles = Role::where('state', $request->state)
                 ->where('district', $request->district)
                 
                 ->where('organisation', $request->organisation)
                 ->where('department_name', $request->department_name)
                 ->where('designation', $request->designation)
                 ->get();

    return response()->json($roles);
}



public function store(Request $request)
{
    
    $validator = Validator::make($request->all(), [
        'state' => 'required',
        'district' => 'required',
        'taluka' => 'nullable', // Taluka is optional
        'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',
        'role_name' => 'required|integer|exists:roles,id',
        'first_name' => 'required|string|max:255',
        'middle_name' => 'nullable|string|max:255', // Middle name is optional
        'last_name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:staffs', // Unique email check in staffs table
        'phone_number' => 'required', // Modify this rule as needed
        'birth_date' => 'required',
        'address' => 'required',
        'password' => 'required|confirmed', // Password confirmation rule
    ]);

    // If validation fails, redirect back with errors
    if ($validator->fails()) {
        return redirect()->back()
            ->withErrors($validator)
            ->withInput();
    }

    // Proceed with storing the data in the 'staffs' table
    $staff = new Staff();
    $staff->state = $request->input('state');
    $staff->district = $request->input('district');
    $staff->taluka = $request->input('taluka'); // Optional field
    $staff->organisation_id = $request->input('organisation');
    $staff->department_id = $request->input('department_name');
    $staff->designation_id = $request->input('designation');
    $staff->role_name = $request->input('role_name');
    $staff->first_name = $request->input('first_name');
    $staff->middle_name = $request->input('middle_name'); // Optional field
    $staff->last_name = $request->input('last_name');
    $staff->email = $request->input('email');
    $staff->phone_number = $request->input('phone_number');
    $staff->birth_date = Carbon::createFromFormat('d M, Y', $request->input('birth_date'))->format('Y-m-d');
    $staff->address = $request->input('address');
    $staff->password = bcrypt($request->input('password'));

    // Save the staff record in the database
    $staff->save();

    return redirect()->route('staff-add.index')->with('success', 'Staff added successfully!');
}


public function edit($id)
{
    $rolePermission = RolePermission::findOrFail($id);
    // Fetch the states and districts data from the JSON file
    $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true);

    // Fetch role permissions and related data with joins
    $user = DB::table('role_permissions')
        ->leftJoin('roles', 'role_permissions.role_name', '=', 'roles.id')
        ->leftJoin('organizations', 'roles.organisation', '=', 'organizations.id')
        ->leftJoin('departments', 'roles.department_name', '=', 'departments.id')
        ->leftJoin('designations', 'roles.designation', '=', 'designations.id')
        ->where('role_permissions.id', $id)
        ->select('role_permissions.id',
            'role_permissions.*',
            'roles.role_name',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

    // Return the view with the required data
    return view('organization-login.assign-permission.edit', [
        'statesData' => $data,
        'user' => $user,
        'rolePermission' => $rolePermission
    ]);
}

public function show($id)
{
    $rolePermission = RolePermission::findOrFail($id);
    // Fetch the states and districts data from the JSON file
    $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true);

    // Fetch role permissions and related data with joins
    $user = DB::table('role_permissions')
        ->leftJoin('roles', 'role_permissions.role_name', '=', 'roles.id')
        ->leftJoin('organizations', 'roles.organisation', '=', 'organizations.id')
        ->leftJoin('departments', 'roles.department_name', '=', 'departments.id')
        ->leftJoin('designations', 'roles.designation', '=', 'designations.id')
        ->where('role_permissions.id', $id)
        ->select('role_permissions.id',
            'role_permissions.*',
            'roles.role_name',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

    // Return the view with the required data
    return view('organization-login.assign-permission.view', [
        'statesData' => $data,
        'user' => $user,
        'rolePermission' => $rolePermission
    ]);
}




   public function update(Request $request, $id)
{
    // Validate the required fields
    $validator = Validator::make($request->all(), [
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'nullable|string|max:255',
        'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',
        'role_name' =>  'required|integer|exists:roles,id',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'errors' => $validator->errors()
        ], 422);
    }

    // Find the RolePermission entry
    $rolePermission = RolePermission::findOrFail($id);

    // Prepare the data for update
    $data = $request->only(['state', 'district', 'organisation', 'department_name', 'designation', 'role_name']);

    // Define the permission types
    $permissions = ['view', 'create', 'edit', 'delete'];

    // Loop through each permission type and set values
    foreach ($permissions as $permission) {
        $data["dashborad_$permission"] = $request->input("dashborad_$permission", 1);
        $data["department_$permission"] = $request->input("department_$permission", 1);
        $data["designation_$permission"] = $request->input("designation_$permission", 1);
        $data["organization_$permission"] = $request->input("organization_$permission", 1);
        $data["staff_$permission"] = $request->input("staff_$permission", 1);
        $data["role_$permission"] = $request->input("role_$permission", 1);
        $data["permission_$permission"] = $request->input("permission_$permission", 1);
        $data["report_$permission"] = $request->input("report_$permission", 1);
        $data["userprofile_$permission"] = $request->input("userprofile_$permission", 1);
        $data["userdetail_$permission"] = $request->input("userdetail_$permission", 1);
        $data["document_$permission"] = $request->input("document_$permission", 1);
        $data["leave_$permission"] = $request->input("leave_$permission", 1);
        $data["nomination_$permission"] = $request->input("nomination_$permission", 1);
        $data["salary_$permission"] = $request->input("salary_$permission", 1);
        $data["checklist_$permission"] = $request->input("checklist_$permission", 1);
        $data["trans_join_$permission"] = $request->input("trans_join_$permission", 1);
    }

    // Update the RolePermission entry
    $rolePermission->update($data);

    return redirect()->route('rolespermission.index')->with('success', 'Role Permission updated successfully!');
}


public function destroy($id)
{
    Staff::findOrFail($id)->delete();

    return response()->json(['message' => 'Role deleted successfully']);
}

public function destroyMultiple(Request $request)
{
    $ids = $request->input('ids');
    if (empty($ids)) {
        return response()->json(['message' => 'No roles selected'], 400);
    }

    Staff::whereIn('id', $ids)->delete();

    return response()->json(['message' => 'Selected roles deleted successfully']);
}


}
