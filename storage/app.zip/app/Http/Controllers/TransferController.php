<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Tehsil;
use App\Models\Transfer;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Validator;



use Illuminate\Support\Facades\Http;

class TransferController extends Controller
{
    
    public function create(){
        
                $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 

        return view('Transfer.add' , ['statesData' => $data]);
    }
    
       public function createJoining(){
        
                $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 

        return view('Transfer.add-joining' , ['statesData' => $data]);
    }
    
    public function store(Request $request)
{
    
   $validated =  $request->validate([
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'required|string|max:255',
        'org_id' => 'required|integer',
                'user_id' => 'required|integer',

        'depart_id' => 'required|integer',
        'design_id' => 'required|string|max:255',
        'formatted_last_working_date' => 'required|date',
        'transfer_state' => 'required|string|max:255',
        'transfer_district' => 'required|string|max:255',
        'transfer_org_id' => 'required|integer',                            
        'transfer_depart_id' => 'required|integer',
        'transfer_taluka' => 'required|string|max:255',
        'transfer_design_id' => 'required|integer',
        'user_digital_sig' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'hod_digital_sig' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'clerk_digital_sig' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ]);

    $userDigitalSigName = null;
    $hodDigitalSigName = null;
    $clerkDigitalSigName = null;


        
if ($request->hasFile('user_digital_sig')) {
    $userDigitalSig = $request->file('user_digital_sig');
    $destinationPath = public_path('/images');
    $userDigitalSigName = time() . '-' . $userDigitalSig->getClientOriginalName();
    $userDigitalSig->move($destinationPath, $userDigitalSigName);
}

if ($request->hasFile('hod_digital_sig')) {
    $hodDigitalSig = $request->file('hod_digital_sig');
    $destinationPath = public_path('/images');
    $hodDigitalSigName = time() . '-' . $hodDigitalSig->getClientOriginalName();
    $hodDigitalSig->move($destinationPath, $hodDigitalSigName);
}

if ($request->hasFile('clerk_digital_sig')) {
    $clerkDigitalSig = $request->file('clerk_digital_sig');
    $destinationPath = public_path('/images');
    $clerkDigitalSigName = time() . '-' . $clerkDigitalSig->getClientOriginalName();
    $clerkDigitalSig->move($destinationPath, $clerkDigitalSigName);
} 
    $status = ($userDigitalSigName && $hodDigitalSigName && $clerkDigitalSigName) ? 'approved' : 'pending';

    $userDetails = Transfer::create([
        'state' => $request->state,
        'district' => $request->district,
        'taluka' => $request->taluka,
        'org_id' => $request->org_id,
        'depart_id' => $request->depart_id,
        'design_id' => $request->design_id,
                'user_id' => $request->user_id,
                  'order_type' => $request->order_type,

        'last_working_date' => $request->formatted_last_working_date,
        'transfer_state' => $request->transfer_state,
        'transfer_district' => $request->transfer_district,
        'transfer_taluka' => $request->transfer_taluka,
        'transfer_org_id' => $request->transfer_org_id,
        'transfer_depart_id' => $request->transfer_depart_id,
        'transfer_design_id' => $request->transfer_design_id,
        'user_dig_sig' => $userDigitalSigName ?? null,
        'hod_dig_sig' => $hodDigitalSigName ?? null,
        'clerk_dig_sig' => $clerkDigitalSigName ?? null,
        'Status' => $status,
    ]);

    return redirect()->back()->with('success', 'User details updated successfully');
}





public function index()
{
    $transfers = DB::table('transfers')
            ->leftJoin('users', 'transfers.user_id', '=', 'users.id')

        ->leftJoin('organizations', 'transfers.org_id', '=', 'organizations.id')
        ->leftJoin('departments', 'transfers.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'transfers.design_id', '=', 'designations.id')
        ->select(
            'transfers.*',
        'users.first_name',
        'users.last_name',

            'organizations.org_name',
            'departments.name as department_name',
            'designations.designation_name'
        )
        ->get();

    return view('Transfer.index', compact('transfers'));
}



public function destroy($id)
{
    $transfer = Transfer::find($id);
    $transfer->delete();

    return response()->json(['id' => $id, 'message' => 'Transfer deleted successfully.']);
}

 public function edit($id)
{
    $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true); 

    $transfer = DB::table('transfers')
            ->leftJoin('users', 'transfers.user_id', '=', 'users.id')

        ->leftJoin('organizations', 'transfers.org_id', '=', 'organizations.id')
        ->leftJoin('departments', 'transfers.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'transfers.design_id', '=', 'designations.id')
        ->where('transfers.id', $id)
        ->select(
            'transfers.*',
                        'users.first_name',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();
            $formatted_last_working_date = $transfer->last_working_date 
        ? Carbon::createFromFormat('Y-m-d', $transfer->last_working_date)->format('Y-m-d') 
        : null;


    return view('Transfer.edit', [
        'statesData' => $data,
        'transfer' => $transfer,
        'formatted_last_working_date' => $formatted_last_working_date,

    ]);
}


public function update(Request $request, $id) {
    $validated = $request->validate([
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'required|string|max:255',
        'org_id' => 'required|integer',
        'user_id' => 'required|integer',
        'depart_id' => 'required|integer',
        'design_id' => 'required|string|max:255',

        'formatted_last_working_date' => 'nullable|date',
        'transfer_state' => 'required|string|max:255',
        'transfer_district' => 'required|string|max:255',
        'transfer_org_id' => 'required|integer',
        'transfer_depart_id' => 'required|integer',
        'transfer_taluka' => 'required|string|max:255',
        'transfer_design_id' => 'required|integer',
        'user_dig_sig' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'hod_dig_sig' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        'clerk_dig_sig' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ]);

    $user = Transfer::find($id);
    $destinationPath = public_path('/images');
        $userFileName = $user->user_dig_sig;
    $hodFileName = $user->hod_dig_sig;
    $clerkFileName = $user->clerk_dig_sig;



    if ($request->hasFile('user_dig_sig')) {
        $oldUserFile = $user->user_dig_sig;  // Use $user instead of $transfer
        if ($oldUserFile && file_exists(public_path('/images/' . $oldUserFile))) {
            unlink(public_path('/images/' . $oldUserFile));
        }

        $userFile = $request->file('user_dig_sig');
        $userFileName = time() . '-' . $userFile->getClientOriginalName();
        $userFile->move($destinationPath, $userFileName);
        $validated['user_dig_sig'] = $userFileName;
    } else {
        $validated['user_dig_sig'] = $user->user_dig_sig;
    }

    if ($request->hasFile('hod_dig_sig')) {
        $oldHodFile = $user->hod_dig_sig;  // Use $user instead of $transfer
        if ($oldHodFile && file_exists(public_path('/images/' . $oldHodFile))) {
            unlink(public_path('/images/' . $oldHodFile));
        }

        $hodFile = $request->file('hod_dig_sig');
        $hodFileName = time() . '-' . $hodFile->getClientOriginalName();
        $hodFile->move($destinationPath, $hodFileName);
        $validated['hod_dig_sig'] = $hodFileName;
    } else {
        $validated['hod_dig_sig'] = $user->hod_dig_sig;
    }

    if ($request->hasFile('clerk_dig_sig')) {
        $oldClerkFile = $user->clerk_dig_sig;  // Use $user instead of $transfer
        if ($oldClerkFile && file_exists(public_path('/images/' . $oldClerkFile))) {
            unlink(public_path('/images/' . $oldClerkFile));
        }

        $clerkFile = $request->file('clerk_dig_sig');
        $clerkFileName = time() . '-' . $clerkFile->getClientOriginalName();
        $clerkFile->move($destinationPath, $clerkFileName);
        $validated['clerk_dig_sig'] = $clerkFileName;
    } else {
        $validated['clerk_dig_sig'] = $user->clerk_dig_sig;
    }
    
        $status = ($userFileName && $hodFileName && $clerkFileName) ? 'approved' : 'pending';

    
    $user->update([
        'Status' => $status,
        'last_working_date' => $request->formatted_last_working_date,
    ]);

    // Update the user with validated data
    $user->update($validated);

    // Separate update for last working date

    return redirect()->route('transfer.index')->with('success', 'User updated successfully.');
}


}