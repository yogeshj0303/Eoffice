<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Tehsil;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Validator;



use Illuminate\Support\Facades\Http;

class UserController extends Controller
{
    // Display the list of users
    
    
    
      public function detailsView(){
          
          
          
        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
        
     

        

        return view('user-profile.view_details_add' , ['statesData' => $data]);
    }
    
      public function detailsViewtable(){
          
          
     
        
             $users = User::all();

                    
        

        return view('user-profile.view_details_table' , compact('users') );
    }
    
    
    
   public function usersdetailsedit($user_id) {
       
                     $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true); 

    $user = DB::table('users')
        ->leftJoin('organizations', 'users.org_id', '=', 'organizations.id')
        ->leftJoin('departments', 'users.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'users.design_id', '=', 'designations.id')
        ->where('users.id', $user_id)
        ->select(
            'users.*',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

    return view('user-profile.view_details_edit', [
        'statesData' => $data,
        'user' => $user
    ]);


    
   
}





   public function create(){
          
          

        $jsonData = file_get_contents(storage_path('data/states_districts.json'));
        $data = json_decode($jsonData, true); 
        
        

        

        return view('user-profile.add' , ['statesData' => $data ] );
    }
    
    

public function fetchProfiles(Request $request)
{
    $designation = $request->input('designation');

    $users = User::where('design_id', $designation)
                 ->get(['id', 'first_name', 'last_name']);

              
    // Return users in JSON format
    return response()->json($users);
}

    
    
    public function getTehsils(Request $request)
{
    $state = $request->input('state');
    $district = $request->input('district');

    // Validate input
    if (!$state || !$district) {
        return response()->json([], 400); // Return empty array if validation fails
    }

    $tehsils = Tehsil::where('state_name', $state)
                     ->where('district_name', $district)
                     ->pluck('th_name');

    return response()->json($tehsils);
}


    public function index()
    {
        $users = User::all();
        
        
        
        
        
        return view('user-profile.index', compact('users'));
    }
    
    
    
    
    
    
  
    // Show form to create a new user
  
    // Store a newly created user
  public function store(Request $request)
{
    
$validator = Validator::make($request->all(), [
        'first_name' => 'required|string|max:255',
        'middle_name' => 'nullable|string|max:255',
        'last_name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email',
        // 'password' => 'required|string|min:6|confirmed',
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
    'formatted_birth_date' => 'required|date|before:today',
        'taluka' => 'required|string|max:255',
                'organisation' => 'required|integer|exists:organizations,id', 
        'department_name' => 'required|integer|exists:departments,id', 
        'designation' => 'required|integer|exists:designations,id',

        'number' => 'required|string|max:20',
        'address' => 'required|string|max:500',
        'address_B' => 'nullable|string|max:500',
        'caste' => 'nullable|string|max:300',
          'gender' => 'nullable|in:male,female',
        'after_mar_first_name' => 'nullable|string|max:255',
        'after_mar_mid_name' => 'nullable|string|max:255',
        'after_mar_last_name' => 'nullable|string|max:255',
        'father_name' => 'nullable|string|max:250',
        'father_address' => 'nullable|string|max:500',
        'birth_text' => 'nullable|string|max:250',
        'height' => 'nullable|string|max:250',
        'birth_mark' => 'nullable|string|max:250',
        'qualification' => 'nullable|string|max:250',
        'another_qualification' => 'nullable|string|max:250',
        'digital_sig' => 'nullable|string|max:250',
        'digital_sig_verify' => 'nullable|string|max:250',
        'certificate_no' => 'nullable|string|max:250',
        'post_name' => 'nullable|string|max:250',
        'leaves' => 'required|integer',
        'old_book' => 'nullable|mimes:pdf,doc,docx ,jpeg,png,jpg,gif',
         'joining_start_salary' => 'required|integer',
           'joining_date' => 'required',
    ]);

   if ($request->hasFile('old_book')) {
            $file = $request->file('old_book');
            $destinationPath = public_path('/images');
            $fileName = time() . '-' . $file->getClientOriginalName();
            $file->move($destinationPath, $fileName);
  
        }
        
        
        

    $user = User::create([
        'first_name' => $request->first_name,
        'middle_name' => $request->middle_name,
        'last_name' => $request->last_name,
        'email' => $request->email,
        // 'password' => bcrypt($request->password),
        'state' => $request->state,
        'district' => $request->district,
        'birth_date' => $request->formatted_birth_date,
        'taluka' => $request->taluka,
        
                'org_id' => $request->organisation, 
        'depart_id' => $request->department_name,
        'design_id' => $request->designation,

        'number' => $request->number,
        'address' => $request->address,
        'address_B' => $request->address_B,
        'caste' => $request->caste,
        'gender' => $request->gender,
        'after_mar_first_name' => $request->after_mar_first_name,
        'after_mar_mid_name' => $request->after_mar_mid_name,
        'after_mar_last_name' => $request->after_mar_last_name,

        'father_name' => $request->father_name,
        'father_address' => $request->father_address,
        'birth_text' => $request->birth_text,
        'height' => $request->height,
        'birth_mark' => $request->birth_mark,
        'qualification' => $request->qualification,
        'another_qualification' => $request->another_qualification,
        'digital_sig' => $request->digital_sig,
        'digital_sig_verify' => $request->digital_sig_verify,
        'certificate_no' => $request->certificate_no,
        'post_name' => $request->post_name,
        'leaves' => $request->leaves,
        'joining_start_salary' => $request->joining_start_salary,
        'joining_date' => $request->joining_date,
        'old_book' => $fileName,
    ]);

    return redirect()->back()->with('success', 'User added successfully!');
}
 public function edit($id)
{
    $jsonData = file_get_contents(storage_path('data/states_districts.json'));
    $data = json_decode($jsonData, true); 

    $user = DB::table('users')
        ->leftJoin('organizations', 'users.org_id', '=', 'organizations.id')
        ->leftJoin('departments', 'users.depart_id', '=', 'departments.id')
        ->leftJoin('designations', 'users.design_id', '=', 'designations.id')
        ->where('users.id', $id)
        ->select(
            'users.*',
            'organizations.org_name',
            'departments.name',
            'designations.designation_name'
        )
        ->first();

    return view('user-profile.edit', [
        'statesData' => $data,
        'user' => $user
    ]);
}




public function update(Request $request, $id)
{

    $user = User::findOrFail($id);
try {
    $validated = $request->validate([
        'first_name' => 'required|string|max:255',
        'middle_name' => 'nullable|string|max:255',
        'last_name' => 'nullable|string|max:255',
        'email' => 'required|email|unique:users,email,' . $id,
        'state' => 'required|string|max:255',
        'district' => 'required|string|max:255',
        'taluka' => 'required|string|max:255',
        'organisation' => 'required|integer|exists:organizations,id',
        'department_name' => 'required|integer|exists:departments,id',
        'designation' => 'required|integer|exists:designations,id',
        'number' => 'required|string|max:20',
        'address' => 'required|string|max:500',
        'address_B' => 'nullable|string|max:500',
        'caste' => 'nullable|string|max:300',
        'gender' => 'nullable|in:male,female',
        'after_mar_first_name' => 'nullable|string|max:255',
        'after_mar_mid_name' => 'nullable|string|max:255',
        'after_mar_last_name' => 'nullable|string|max:255',
        'father_name' => 'nullable|string|max:250',
        'father_address' => 'nullable|string|max:500',
        'birth_text' => 'nullable|string|max:250',
        'height' => 'nullable|string|max:250',
        'birth_mark' => 'nullable|string|max:250',
        'qualification' => 'nullable|string|max:250',
        'another_qualification' => 'nullable|string|max:250',
        'digital_sig' => 'nullable|string|max:250',
        'digital_sig_verify' => 'nullable|string|max:250',
        'certificate_no' => 'nullable|string|max:250',
        'post_name' => 'nullable|string|max:250',
        'leaves' => 'required|integer',
        'old_book' => 'nullable|mimes:pdf,doc,docx,jpeg,png,jpg,gif',
    ]);

    dd($validated); // This will dump the validated data if successful
} catch (\Illuminate\Validation\ValidationException $e) {
    dd($e->errors());
}

    $destinationPath = public_path('/images');
        $userFileName = $user->old_book;
        

    if ($request->hasFile('old_book')) {
        $oldUserFile = $user->old_book; 
        if ($oldUserFile && file_exists(public_path('/images/' . $oldUserFile))) {
            unlink(public_path('/images/' . $oldUserFile));
        }

        $userFile = $request->file('old_book');
        $userFileName = time() . '-' . $userFile->getClientOriginalName();
        $userFile->move($destinationPath, $userFileName);
        $validated['old_book'] = $userFileName;
    } else {
        $validated['old_book'] = $user->old_book;
    }


  // if ($request->filled('password')) {
    //     $validated['password'] = bcrypt($validated['password']);
    // } else {
    //     unset($validated['password']);
    // }
                
                

    $user->update($validated);
  
    return redirect()->route('users.index')->with('success', 'User updated successfully.');
}




public function updateuserdetails(Request $request)
{
        $validated = $request->validate([
            'state' => 'required',
            'district' => 'required',
            'taluka' => 'required',
            'organisation' => 'required|integer|exists:organizations,id',
            'department_name' => 'required|integer|exists:departments,id',
            'designation' => 'required|integer|exists:designations,id',
            'name' => 'required',
            'caste' => 'nullable|string',
                      'gender' => 'nullable|in:male,female',

                    'after_mar_first_name' => 'nullable|string|max:255',
        'after_mar_mid_name' => 'nullable|string|max:255',
        'after_mar_last_name' => 'nullable|string|max:255',

            'address' => 'nullable|string',
            'address_B' => 'nullable|string',
            'father_name' => 'nullable|string',
            'father_address' => 'nullable|string',
            'birth_date' => 'required|date|before:today',
            'formatted_joining_date' => 'required|date|before:today',
            'joining_start_salary' => 'required',
            'birth_text' => 'nullable|string',
            'height' => 'nullable|string',
            'birth_mark' => 'nullable|string',
            'qualification' => 'nullable|string',
            'another_qualification' => 'nullable|string',
            'digital_sig' => 'required|image|mimes:jpeg,png,jpg,gif',
            'digital_sig_verify' => 'required|image|mimes:jpeg,png,jpg,gif',
            'certificate_no' => 'nullable|string',
            'post_name' => 'required|image|mimes:jpeg,png,jpg,gif',
        ]);


    $user = User::find($request->name);

    // Prepare data for update
    $data = $request->except(['digital_sig', 'digital_sig_verify', 'post_name']);

    if ($request->hasFile('digital_sig') && $request->file('digital_sig')->isValid()) {
        $file = $request->file('digital_sig');
        $extension = $file->getClientOriginalExtension();
        $filename = time() . '.' . $extension;
        $path = 'images/' . $filename;

        $file->move(public_path('images'), $filename);
        $data['digital_sig'] = $path;
    }

    if ($request->hasFile('digital_sig_verify') && $request->file('digital_sig_verify')->isValid()) {
        $file = $request->file('digital_sig_verify');
        $extension = $file->getClientOriginalExtension();
        $filename = time() . '.' . $extension;
        $path = 'images/' . $filename;

        $file->move(public_path('images'), $filename);
        $data['digital_sig_verify'] = $path;
    }

    if ($request->hasFile('post_name') && $request->file('post_name')->isValid()) {
        $file = $request->file('post_name');
        $extension = $file->getClientOriginalExtension();
        $filename = time() . '.' . $extension;
        $path = 'images/' . $filename;

        $file->move(public_path('images'), $filename);
        $data['post_name'] = $path;
    }
       
       


             
    $user->update($data);
  $user->update([
        'joining_date' => $request->formatted_joining_date,

]);

    return redirect()->back()->with('success', 'User updated successfully.');
}




public function getUserDetails($id)
{
    $user = User::find($id);
    
    
       if ($user) {
        return response()->json([
            'address' => $user->address,
            'address_B' => $user->address_B,
            'caste' => $user->caste,
            'father_name' => $user->father_name,
            'father_address' => $user->father_address,
    'birth_date' => $user->birth_date->format('Y-m-d'), 
            'birth_text' => $user->birth_text,
                        'first_name' => $user->first_name,
            'middle_name' => $user->middle_name,
            'last_name' => $user->last_name,

            'height' => $user->height,
            'birth_mark' => $user->birth_mark,
            'qualification' => $user->qualification,
            'another_qualification' => $user->another_qualification,
            
            'digital_sig' => $user->digital_sig ? url( $user->digital_sig) : null,
'digital_sig_verify' => $user->digital_sig_verify ? url($user->digital_sig_verify) : null,
'certificate_no' => $user->certificate_no,
'post_name' => $user->post_name ? url('images/' . $user->post_name) : null,

            
        ]);
        
        
       }
 else {
        return response()->json(['error' => 'User not found'], 404);
    }
}


public function destroy($id)
{
    $user = User::findOrFail($id);
    $user->delete();

    return response()->json(['id' => $id, 'message' => 'User deleted successfully.']);
}
















public function fetchSalary(Request $request)
{
    $profileId = $request->input('profile_id');

    $user = User::find($profileId, ['joining_start_salary', 'joining_date']);

    if ($user) {
        return response()->json($user);
    }

    return response()->json(null);
}


}
