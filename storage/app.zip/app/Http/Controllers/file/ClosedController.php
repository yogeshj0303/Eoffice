<?php
namespace App\Http\Controllers\file;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class ClosedController extends Controller
{
    public function index()
    {
        
        return view('file.closed.index');
    }
    
  }
