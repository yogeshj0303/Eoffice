<?php
namespace App\Http\Controllers\file;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class CompleteController extends Controller
{
    public function index()
    {
        
        return view('file.created.Complete.index');
    }
    
    public function create()
    {
        return view('file.created.Complete.add');
    }
    
    public function volume(){
        return view('file.created.Complete.volume');
    }
}
