<?php

namespace App\Http\Controllers\file;

use App\Http\Controllers\Controller;


use Illuminate\Http\Request;

class DraftController extends Controller
{
    public function index()
    {
        
        return view('file.created.Draft.index');
    }
    
    public function create()
    {
        return view('file.created.Draft.add');
    }
}
