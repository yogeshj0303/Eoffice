<?php
namespace App\Http\Controllers\file;
use App\Http\Controllers\Controller;
use App\Models\Diary;
use App\Models\File;

use Illuminate\Http\Request;

class ElectronicsController extends Controller
{
    public function create()
    {
        return view('file.electronic.sfs');
    }
    
    
    public function store(Request $request)
{
    $validatedData = $request->validate([
        'diary_date' => 'nullable|date',
        'diary_forms_comm' => 'required|string',
        'diary_lang' => 'required|string',
        'diary_received_date' => 'nullable|date',
        'diary_letter_date' => 'nullable|date',
        'diary_letter_ref_no' => 'nullable|string',
        'diary_delivery_mode' => 'required|string',
        'diary_mode_on' => 'nullable|string',
        'diary_sender_type' => 'required|string',
        'diary_vip' => 'nullable|string',
        'name' => 'required|string',
        'designation' => 'required|string',
        'organisation' => 'nullable|string',
        'mobile_no' => 'nullable|string',
        'email' => 'nullable|email',
        'address' => 'required|string',
        'country' => 'required|string',
        'state' => 'required|string',
        'city' => 'nullable|string',
        'pincode' => 'nullable|string',
        'landline' => 'nullable|string',
        'fax' => 'nullable|string',
        'main_category' => 'required|string',
        'sub_category' => 'nullable|string',
        'subject' => 'required|string',
        'remark' => 'nullable|string',
                'upload_file' => 'required|file|mimes:pdf|max:2048', 

    ]);
    
    
    
   if ($request->hasFile('upload_file')) {
            $file = $request->file('upload_file');
            $destinationPath = public_path('/images');
            $fileName = time() . '-' . $file->getClientOriginalName();
            $file->move($destinationPath, $fileName);
  
        }
        


  $diary =   Diary::create([
        'diary_date' => $validatedData['diary_date'],
        'diary_forms_comm' => $validatedData['diary_forms_comm'],
        'diary_lang' => $validatedData['diary_lang'],
        'diary_received_date' => $validatedData['diary_received_date'],
        'diary_letter_date' => $validatedData['diary_letter_date'],
        'diary_letter_ref_no' => $validatedData['diary_letter_ref_no'],
        'diary_delivery_mode' => $validatedData['diary_delivery_mode'],
        'diary_mode_on' => $validatedData['diary_mode_on'],
        'diary_sender_type' => $validatedData['diary_sender_type'],
        'diary_vip' => $validatedData['diary_vip'],
        'name' => $validatedData['name'],
        'designation' => $validatedData['designation'],
        'organisation' => $validatedData['organisation'],
        'mobile_no' => $validatedData['mobile_no'],
        'email' => $validatedData['email'],
        'address' => $validatedData['address'],
        'country' => $validatedData['country'],
        'state' => $validatedData['state'],
        'city' => $validatedData['city'],
        'pincode' => $validatedData['pincode'],
        'landline' => $validatedData['landline'],
        'fax' => $validatedData['fax'],
        'main_category' => $validatedData['main_category'],
        'sub_category' => $validatedData['sub_category'],
        'subject' => $validatedData['subject'],
        'remark' => $validatedData['remark'],
        'file_type' => 'electronics', 
        'upload_file' => $fileName,
    ]);

    // Redirect back with success message
return redirect()->route('non-sfs-electronic', ['id' => $diary->id])->with('success', 'Data has been saved successfully!');
}



public function show($id)
{
    $diary = Diary::find($id);
    
    return view('file.electronic.non-sfs', compact('diary'));
}

public function getUserSuggestions(Request $request)
{
    $query = $request->input('query');

    // Query the database for matching names
    $users = Diary::where('name', 'LIKE', '%' . $query . '%')
        ->get(['id', 'name', 'designation', 'organisation', 'mobile_no', 'email', 'address', 'country', 'state', 'city', 'pincode', 'landline', 'fax']);

    // Return matching user details as JSON
    return response()->json($users);
}




public function filestore(Request $request){
    
    
            $validatedData = $request->validate([
            'nature' => 'required|string',
            'type' => 'required|string',
            'fileno_1' => 'required|string',
            'fileno_2' => 'required|string',
            'fileno_3' => 'required|string',
            'fileno_4' => 'nullable|string',
            'fileno_5' => 'required|string',
            'fileno_6' => 'required|string',
            'description' => 'required|string',
            'main_category' => 'required|string',
            'sub_category' => 'required|string',
            'classified' => 'required|string',
            'remarks' => 'nullable|string',
            'previous_ref' => 'nullable|string',
            'later_ref' => 'nullable|string',
        ]);

        File::create($validatedData);

        return redirect()->back()->with('success', 'file entry created successfully!');

    
    
    
}




}
