<?php
namespace App\Http\Controllers\file;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class ParkedController extends Controller
{
    public function index()
    {
        
        return view('file.parked.index');
    }
    
  }
