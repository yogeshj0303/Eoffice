<?php
namespace App\Http\Controllers\file;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class SentController extends Controller
{
    public function index()
    {
        
        return view('file.sent.index');
    }
    public function createpart()
    {
        
        return view('file.sent.createpart');
    }
    
  }
