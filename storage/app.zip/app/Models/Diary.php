<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Diary extends Model
{
    use HasFactory;

    protected $table = 'diary_details';

    protected $fillable = [
        'file_type',
        'diary_date',
        'diary_forms_comm',
        'diary_lang',
        'diary_received_date',
        'diary_letter_date',
        'diary_letter_ref_no',
        'diary_delivery_mode',
        'diary_mode_on',
        'diary_vip',
        'state',
        'city',
        'organisation',
        'country',
        'taluka',
        'designation',
        'name',
        'mobile_no',
        'email',
        'address',
        'pincode',
        'landline',
        'fax',
        'main_category',
        'sub_category',
        'subject',
        'remark',
        'diary_sender_type',
        'upload_file',
    ];

    protected $dates = [
        'diary_date',
        'diary_received_date',
        'diary_letter_date',
        'created_at',
        'updated_at',
    ];

    public $timestamps = true;
}
