<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class File extends Model
{
    use HasFactory;

    protected $table = 'files';

    protected $fillable = [
        'diary_id',
        'nature',
        'type',
        'fileno_1',
        'fileno_2',
        'fileno_3',
        'fileno_4',
        'fileno_5',
        'fileno_6',
        'description',
        'main_category',
        'sub_category',
        'classified',
        'remarks',
        'previous_ref',
        'later_ref',
    ];

    protected $primaryKey = 'id';

    public $incrementing = true;

    protected $keyType = 'int';
}
