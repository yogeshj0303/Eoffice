<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    use HasFactory;

    protected $table = 'leaves';

    protected $fillable = [
        'user_id',
        'state',
        'district',
        'taluka',
                'org_id',
        'depart_id',
        'design_id',

        'subject',
        'description',
        'start_date',
        'end_date',
        'leave_days',
        'available_leave',
        'apply_start_date',
        'apply_end_date',
        'approver',
        'rejecter',
        'reject_description',
        'status'
    ];

    protected $primaryKey = 'id';

    public $timestamps = true;

}
