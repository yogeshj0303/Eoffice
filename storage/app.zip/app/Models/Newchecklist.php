<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Newchecklist extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'newchecklists';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'state',
        'district',
        'taluka',
        'org_id',
        'depart_id',
        'design_id',
        'user_id',
        'checklist_name',
        'process_status',
        'page_no',
        'Status',
        'page_file',
        'receipt_no',
        'receipt_status',
    ];
}
