<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Nomination extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'nominations';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'state',
        'district',
        'taluka',
                'org_id',
        'depart_id',
        'design_id',

        'user_id',
        'position',
        'birth_date',
        'join_date',
        'nomination_type',
        'digital_sig_user',
        'digital_sig_clerk',
        'digital_sig_head',
        'witness_sig_one',
        'witness_sig_two',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'birth_date' => 'date',
        'join_date' => 'date',
    ];
}
