<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NominationDetail extends Model
{
    use HasFactory;

    protected $table = 'nomination_details';

    protected $fillable = [
        
        'nomination_id',
        'nominee_name',
        'nominee_dob',
        'nominee_age',
        'atypical_event',
        'relationship_nominee',
        'nominee_type',
        'nominee_amount',
    ];

    // Optionally, define any relationships or additional model logic here.
}
