<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RolePermission extends Model
{
    use HasFactory;

    // Define the table name if it doesn't follow Laravel's naming convention
    protected $table = 'role_permissions';

    // Define the fillable attributes for mass assignment
    protected $fillable = [
        'state',
        'district',
        'organisation',
        'department_name',
        'designation',
        'role_name',
        'taluka',
        'dashborad_view',
        'dashborad_create',
        'dashborad_edit',
        'dashborad_delete',
        'department_view',
        'department_create',
        'department_edit',
        'department_delete',
        'designation_view',
        'designation_create',
        'designation_edit',
        'designation_delete',
        'organization_view',
        'organization_create',
        'organization_edit',
        'organization_delete',
        'staff_view',
        'staff_create',
        'staff_edit',
        'staff_delete',
        'role_view',
        'role_create',
        'role_edit',
        'role_delete',
        'permission_view',
        'permission_create',
        'permission_edit',
        'permission_delete',
        'report_view',
        'report_create',
        'report_edit',
        'report_delete',
        'userprofile_view',
        'userprofile_create',
        'userprofile_edit',
        'userprofile_delete',
        'userdetail_view',
        'userdetail_create',
        'userdetail_edit',
        'userdetail_delete',
        'document_view',
        'document_create',
        'document_edit',
        'document_delete',
        'leave_view',
        'leave_create',
        'leave_edit',
        'leave_delete',
        'nomination_view',
        'nomination_create',
        'nomination_edit',
        'nomination_delete',
        'salary_view',
        'salary_create',
        'salary_edit',
        'salary_delete',
        'checklist_view',
        'checklist_create',
        'checklist_edit',
        'checklist_delete',
        'trans_join_view',
        'trans_join_create',
        'trans_join_edit',
        'trans_join_delete',
    ];

    // Optionally, you can set timestamps to true if you want to manage created_at and updated_at
    public $timestamps = true;
}
