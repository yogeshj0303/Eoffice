<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;

    // Specify the table name if it's not the plural of the model name
    protected $table = 'staffs';

    // Define the fillable fields for mass assignment
    protected $fillable = [
        'first_name',
        'middle_name',
        'last_name',
        'email',
        'phone_number',
        'birth_date',
        'address',
        'state',
        'district',
        'taluka',
        'organisation_id',
        'department_id',
        'designation_id',
        'role_name',
        'password',
    ];

    // Optionally, if you want to hide sensitive data from JSON responses
    protected $hidden = [
        'password',
    ];

    // If you want to use timestamps
    public $timestamps = true;
}
