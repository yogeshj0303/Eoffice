<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable; // Extend if staff needs authentication
use Illuminate\Notifications\Notifiable;
use Carbon\Carbon;

class Staff extends Authenticatable
{
    use HasFactory, Notifiable;

    // Table associated with the model
    protected $table = 'staffs';

    // Fillable properties for mass assignment
    protected $fillable = [
        'state',
        'district',
        'taluka',
        'organisation_id',
        'department_id',
        'designation_id',
        'role_id',
        'first_name',
        'middle_name',
        'last_name',
        'email',
        'phone_number',
        'birth_date',
        'address',
        'password',
    ];

    // Hidden properties (e.g. password, remember_token for authentication)
    protected $hidden = [
        'password',
        'remember_token',
    ];

   

    // Define the organisation relationship
    public function organisation()
    {
        return $this->belongsTo(Organisation::class, 'organisation_id');
    }

    // Define the department relationship
    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    // Define the designation relationship
    public function designation()
    {
        return $this->belongsTo(Designation::class, 'designation_id');
    }

    // Define the role relationship
    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    // Define an accessor for the full name (first, middle, last)
    public function getFullNameAttribute()
    {
        return "{$this->first_name} {$this->middle_name} {$this->last_name}";
    }

    // Mutator for hashing passwords before saving to the database
    public function setPasswordAttribute($password)
    {
        $this->attributes['password'] = bcrypt($password);
    }
}
