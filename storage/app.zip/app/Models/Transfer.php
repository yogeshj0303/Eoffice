<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transfer extends Model
{
    use HasFactory;

    protected $fillable = [
        'state',
        'district',
        'taluka',
        'org_id',
        'depart_id',
        'order_type',
        'design_id',
        'user_id',
        'last_working_date',
        'transfer_state',
        'transfer_district',
        'transfer_taluka',
        'transfer_org_id',
        'transfer_depart_id',
        'transfer_design_id',
        'user_dig_sig',
        'hod_dig_sig',
        'clerk_dig_sig',
        'Status',
    ];
}
