<?php
namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'is_admin',
         'username',
        'first_name',
                'org_id',
        'depart_id',
        'design_id',

        'middle_name',
        'last_name',
        'number',
        'address',
        'state',
        'district',
        'taluka',
        'leaves',
        'email',
        'login_status',
        'caste',
        'gender',
        'after_mar_first_name',
        'after_mar_mid_name',
        'after_mar_last_name',
        'address_B',
        'father_name',
        'father_address',
        'birth_date',
        'birth_text',
        'birth_mark',
        'height',
        'qualification',
        'another_qualification',
        'digital_sig',
        'digital_sig_verify',
        'certificate_no',
        'post_name',
        'old_book',
        'joining_start_salary',
        'joining_date',
        'remember_token',
    ];
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'birth_date' => 'date',
        'login_status' => 'boolean',
    ];
}
