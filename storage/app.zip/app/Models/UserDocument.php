<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserDocument extends Model
{
    use HasFactory;

    protected $table = 'user_documents';


    protected $primaryKey = 'id';

    public $timestamps = true;
    
    
        protected $fillable = [
        'user_id',
        'state',
        'district',
        'taluka',
        'org_id',
        'depart_id',
        'design_id',
        'document_name',
        'document_pdf'
    ];


}
